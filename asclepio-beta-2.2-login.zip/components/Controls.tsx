import React, { useState } from 'react';
import { InteractionStatus } from '../types.ts';
import { StopIcon } from './icons/StopIcon.tsx';
import { TextIcon } from './icons/TextIcon.tsx';
import { SendIcon } from './icons/SendIcon.tsx';
import { NewChatIcon } from './icons/NewChatIcon.tsx';
import { SubtitlesIcon } from './icons/SubtitlesIcon.tsx';
import { PresentationIcon } from './icons/PresentationIcon.tsx';
import { SearchIcon } from './icons/SearchIcon.tsx';

interface ControlsProps {
  status: InteractionStatus;
  onInterrupt: () => void;
  onSubmitText: (text: string) => void;
  onReset: () => void;
  subtitlesEnabled: boolean;
  onToggleSubtitles: () => void;
  isPresentationMode: boolean;
  onTogglePresentationMode: () => void;
  isSearchMode: boolean;
  onToggleSearchMode: () => void;
}

const ControlButton: React.FC<{
    onClick?: () => void;
    disabled?: boolean;
    isActive?: boolean;
    children: React.ReactNode;
    ariaLabel: string;
    "data-tutorial-id"?: string;
}> = ({ onClick, disabled, isActive, children, ariaLabel, "data-tutorial-id": dataTutorialId }) => (
    <button
        onClick={onClick}
        disabled={disabled}
        aria-label={ariaLabel}
        data-tutorial-id={dataTutorialId}
        className={`p-3 rounded-full transition-all duration-200 transform active:scale-90
            ${isActive ? 'text-white bg-[var(--accent)]' : 'text-[var(--text-secondary)] hover:text-[var(--accent)] hover:bg-[var(--accent-light)]'}
            ${disabled ? 'opacity-30 !text-[var(--text-secondary)] cursor-not-allowed hover:bg-transparent' : ''}
        `}
    >
        {children}
    </button>
);


export const Controls: React.FC<ControlsProps> = ({ status, onInterrupt, onSubmitText, onReset, subtitlesEnabled, onToggleSubtitles, isPresentationMode, onTogglePresentationMode, isSearchMode, onToggleSearchMode }) => {
  const [isTextMode, setIsTextMode] = useState(false);
  const [text, setText] = useState('');

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onSubmitText(text);
      setText('');
      setIsTextMode(false);
    }
  };
  
  const isProcessing = status === InteractionStatus.THINKING;

  return (
    <div className="relative">
      <div className="bg-[var(--control-bg)] border border-[var(--border-color)] backdrop-blur-2xl rounded-full shadow-xl shadow-black/10 p-1.5 flex items-center justify-center gap-1 transition-all duration-300 w-full">
        {isTextMode ? (
          <form onSubmit={handleSend} className="w-full flex items-center gap-2 pl-4 pr-2">
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Escribe tu mensaje..."
              className="w-full bg-transparent text-[var(--text-primary)] placeholder:text-[var(--text-secondary)] focus:outline-none py-1"
              autoFocus
              onBlur={() => !text && setIsTextMode(false)}
            />
            <button type="submit" disabled={!text.trim() || isProcessing} className="p-2 rounded-full text-[var(--accent)] disabled:text-[var(--text-secondary)] disabled:opacity-50 transition-colors">
              <SendIcon className="w-6 h-6" />
            </button>
          </form>
        ) : (
          <>
            <ControlButton onClick={onReset} disabled={isProcessing} ariaLabel="Nueva conversación" data-tutorial-id="new-chat-button">
               <NewChatIcon className="w-6 h-6" />
            </ControlButton>
             <ControlButton
              onClick={onInterrupt}
              disabled={status !== InteractionStatus.SPEAKING}
              ariaLabel="Interrumpir"
              data-tutorial-id="interrupt-button"
            >
              <StopIcon className="w-7 h-7" />
            </ControlButton>
            <ControlButton onClick={onTogglePresentationMode} isActive={isPresentationMode} disabled={isProcessing} ariaLabel="Modo presentación" data-tutorial-id="presentation-mode-button">
                <PresentationIcon className="w-6 h-6" />
            </ControlButton>
            <ControlButton onClick={onToggleSearchMode} isActive={isSearchMode} disabled={isProcessing} ariaLabel="Modo búsqueda" data-tutorial-id="search-mode-button">
                <SearchIcon className="w-6 h-6" />
            </ControlButton>
            <ControlButton onClick={() => setIsTextMode(true)} disabled={isProcessing} ariaLabel="Escribir texto" data-tutorial-id="text-mode-button">
              <TextIcon className="w-6 h-6" />
            </ControlButton>
            <ControlButton 
              onClick={onToggleSubtitles} 
              isActive={subtitlesEnabled}
              ariaLabel="Activar subtítulos"
              data-tutorial-id="subtitles-button"
            >
              <SubtitlesIcon className="w-6 h-6" />
            </ControlButton>
          </>
        )}
      </div>
    </div>
  );
};