import React, { useRef, useEffect } from 'react';
import { BoardContent, BoardContentType, Theme } from '../types.ts';
import { GuitarFretboard } from './widgets/GuitarFretboard.tsx';
import { CodeBlock } from './widgets/CodeBlock.tsx';
import { DownloadIcon } from './icons/DownloadIcon.tsx';
import { FlashcardsView } from './widgets/FlashcardsView.tsx';
import { QuizView } from './widgets/QuizView.tsx';
import { PresentationView } from './widgets/PresentationView.tsx';


const BoardContainer: React.FC<{ children: React.ReactNode, ref: React.Ref<HTMLDivElement> }> = React.forwardRef(({ children }, ref) => (
    <div 
        className="bg-[var(--board-bg)] border border-[var(--border-color)] backdrop-blur-2xl rounded-2xl shadow-2xl shadow-black/5 p-4 sm:p-6 w-full"
        ref={ref}
    >
        {children}
    </div>
));

const TextView: React.FC<{ htmlContent: string }> = ({ htmlContent }) => (
    <div 
        className="text-[var(--text-primary)] text-base sm:text-lg font-light leading-relaxed whitespace-pre-wrap p-2 highlightable-content"
        dangerouslySetInnerHTML={{ __html: htmlContent }}
    />
);

const ImageView: React.FC<{ data: { src: string, prompt: string } }> = ({ data }) => {
    const handleDownload = () => {
        const link = document.createElement('a');
        link.href = data.src;
        // Create a filename-safe version of the prompt
        const fileName = data.prompt.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '-').substring(0, 50) || 'asclepio-image';
        link.download = `${fileName}.jpg`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    return (
        <div className="relative group">
            <img src={data.src} alt={data.prompt} className="w-full h-auto object-contain rounded-lg" />
            <button
                onClick={handleDownload}
                className="absolute top-2 right-2 p-1.5 bg-gray-500/20 hover:bg-gray-500/40 text-white rounded-md transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 z-10"
                aria-label="Descargar imagen"
            >
                <DownloadIcon className="w-5 h-5" />
            </button>
        </div>
    );
};

const YouTubeView: React.FC<{ videoId: string, title: string }> = ({ videoId, title }) => (
    <div className="w-full">
        <iframe
            className="w-full aspect-video rounded-lg"
            src={`https://www.youtube.com/embed/${videoId}?autoplay=1`}
            title={title}
            frameBorder="0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
        ></iframe>
    </div>
);

const ArticleView: React.FC<{ title: string, summary: string, url: string }> = ({ title, summary, url }) => (
    <div className="flex flex-col p-2">
        <h3 className="text-xl sm:text-2xl font-bold mb-3">{title}</h3>
        <div 
            className="text-base sm:text-lg font-light leading-relaxed mb-4 highlightable-content"
            dangerouslySetInnerHTML={{ __html: summary }}
        />
        <a 
            href={url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-sm text-[var(--accent)] hover:underline mt-auto"
        >
            Leer artículo completo
        </a>
    </div>
);

const WebView: React.FC<{ url: string }> = ({ url }) => {
    try {
        const safeUrl = new URL(url).href; // Basic validation
        return (
            <div className="w-full h-[65vh] flex flex-col overflow-hidden">
                <div className="flex-shrink-0 p-2 bg-black/5 dark:bg-black/10 flex items-center justify-between text-xs rounded-t-lg">
                    <span className="text-[var(--text-secondary)] truncate mr-4">{safeUrl}</span>
                    <a href={safeUrl} target="_blank" rel="noopener noreferrer" className="text-[var(--accent)] hover:underline whitespace-nowrap font-medium">
                        Abrir en nueva pestaña
                    </a>
                </div>
                <iframe
                    src={safeUrl}
                    title="Visor Web"
                    className="w-full h-full border-0"
                    sandbox="allow-forms allow-modals allow-pointer-lock allow-popups allow-popups-to-escape-sandbox allow-presentation allow-same-origin allow-scripts"
                    onError={() => console.warn(`Iframe a ${safeUrl} bloqueado por X-Frame-Options.`)}
                />
            </div>
        );
    } catch(e) {
        return <div className="text-[var(--error)] p-4">La URL proporcionada no es válida: {url}</div>;
    }
};


export const InformationBoard: React.FC<{ content: BoardContent | null, currentHighlightId: string | null, theme: Theme }> = ({ content, currentHighlightId, theme }) => {
  const boardRef = useRef<HTMLDivElement>(null);
  const animationKey = content ? JSON.stringify(content.data) : 'empty';

  useEffect(() => {
    if (!boardRef.current) return;

    // Remove previous highlight
    const previouslyHighlighted = boardRef.current.querySelector('.highlighted');
    previouslyHighlighted?.classList.remove('highlighted');

    // Add new highlight
    if (currentHighlightId) {
      const elementToHighlight = boardRef.current.querySelector(`#${currentHighlightId}`);
      if (elementToHighlight) {
          elementToHighlight.classList.add('highlighted');
          elementToHighlight.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }
  }, [currentHighlightId]);

  if (!content) {
    return null; // Don't render anything if there's no content
  }

  // A wrapper is needed for non-padded content like iframes and images.
  const BoardWrapper: React.FC<{children: React.ReactNode, hasPadding?: boolean}> = ({ children, hasPadding = true }) => (
    <div className={hasPadding ? "p-4 sm:p-6" : ""}>{children}</div>
  );

  const renderContent = () => {
    switch (content.type) {
      case BoardContentType.TEXT:
        return <BoardWrapper><TextView htmlContent={content.data} /></BoardWrapper>;
      case BoardContentType.IMAGE:
        return <BoardWrapper hasPadding={false}><ImageView data={content.data} /></BoardWrapper>;
      case BoardContentType.GUITAR_FRETBOARD:
        return <BoardWrapper><GuitarFretboard data={content.data} /></BoardWrapper>;
      case BoardContentType.YOUTUBE_VIDEO:
        return <BoardWrapper hasPadding={false}><YouTubeView videoId={content.data.videoId} title={content.data.title} /></BoardWrapper>;
      case BoardContentType.WEB_ARTICLE:
        return <BoardWrapper><ArticleView title={content.data.title} summary={content.data.summary} url={content.data.url} /></BoardWrapper>;
      case BoardContentType.CODE:
        return <BoardWrapper hasPadding={false}><CodeBlock language={content.data.language} code={content.data.code} theme={theme} /></BoardWrapper>;
       case BoardContentType.FLASHCARDS:
        return <BoardWrapper><FlashcardsView data={content.data} /></BoardWrapper>;
      case BoardContentType.QUIZ:
        return <BoardWrapper><QuizView data={content.data} /></BoardWrapper>;
      case BoardContentType.PRESENTATION:
        return <BoardWrapper><PresentationView data={content.data} /></BoardWrapper>;
      case BoardContentType.WEB_PAGE:
        return <BoardWrapper hasPadding={false}><WebView url={content.data.url} /></BoardWrapper>;
      default:
        return null;
    }
  };

  return (
    <div key={animationKey} className="animate-fade-in w-full h-auto">
        <div 
            ref={boardRef}
            className="bg-[var(--board-bg)] border border-[var(--border-color)] backdrop-blur-2xl rounded-2xl shadow-2xl shadow-black/5 w-full overflow-hidden"
        >
            {renderContent()}
        </div>
    </div>
  );
};