import React, { useState, useEffect, useMemo } from 'react';
import { InteractionStatus, FaceCustomization } from '../types.ts';

interface AsclepioFaceProps {
  status: InteractionStatus;
  isBoardVisible: boolean;
  customization: FaceCustomization;
}

const MOUTH_SHAPES = [
    "M 130 200 Q 160 215 190 200", // ooh
    "M 130 200 Q 160 228 190 200", // O
    "M 135 200 L 185 200", // eee
    "M 130 205 Q 160 200 190 205", // smile
];

const Mouth: React.FC<{ status: InteractionStatus; color: string }> = ({ status, color }) => {
    const [path, setPath] = useState("M 130 200 Q 160 200 190 200");
    
    const strokeColor = useMemo(() => status === InteractionStatus.ERROR ? "var(--error)" : color, [status, color]);

    useEffect(() => {
        let intervalId: ReturnType<typeof setInterval> | undefined;

        if (status === InteractionStatus.SPEAKING) {
            intervalId = setInterval(() => {
                const randomShape = MOUTH_SHAPES[Math.floor(Math.random() * MOUTH_SHAPES.length)];
                setPath(randomShape);
            }, 180);
        } else {
            switch (status) {
                case InteractionStatus.LISTENING:
                    setPath("M 130 200 Q 160 205 190 200");
                    break;
                case InteractionStatus.THINKING:
                    setPath("M 150 200 A 10 10 0 1 1 170 200 A 10 10 0 1 1 150 200");
                    break;
                case InteractionStatus.ERROR:
                    setPath("M 130 205 L 190 195");
                    break;
                default:
                    setPath("M 130 200 Q 160 200 190 200");
                    break;
            }
        }
        return () => clearInterval(intervalId);
    }, [status]);

    return <path d={path} stroke={strokeColor} strokeWidth="3" fill="none" strokeLinecap="round" className="transition-all duration-200 ease-in-out" />;
};

const Eyes: React.FC<{ status: InteractionStatus; isBoardVisible: boolean; color: string }> = ({ status, isBoardVisible, color }) => {
    const [isBlinking, setIsBlinking] = useState(false);
    const [gaze, setGaze] = useState<'center' | 'board'>('center');
    
    const isGazeCycleActive = isBoardVisible && (status === InteractionStatus.SPEAKING || status === InteractionStatus.THINKING);

    useEffect(() => {
        if (!isGazeCycleActive) {
            setGaze('center');
            return;
        }

        let gazeTimer: ReturnType<typeof setTimeout> | undefined;
        let cycleTimer: ReturnType<typeof setTimeout> | undefined;

        const gazeCycle = () => {
            setGaze('board');
            gazeTimer = setTimeout(() => {
                setGaze('center');
            }, 2000); // Look at board for 2s

            cycleTimer = setTimeout(gazeCycle, 5000); // Repeat cycle every 5s (2s looking + 3s returning)
        };

        gazeCycle();

        return () => {
            if (gazeTimer) clearTimeout(gazeTimer);
            if (cycleTimer) clearTimeout(cycleTimer);
        };
    }, [isGazeCycleActive]);


    const baseEyeX = { left: 125, right: 195 };
    const gazeShift = 10;
    
    const eyeX = useMemo(() => ({
        left: gaze === 'board' ? baseEyeX.left + gazeShift : baseEyeX.left,
        right: gaze === 'board' ? baseEyeX.right + gazeShift : baseEyeX.right,
    }), [gaze]);
    
    const eyeTransitionDuration = useMemo(() => gaze === 'center' ? '3000ms' : '300ms', [gaze]);


    useEffect(() => {
        let blinkInterval: ReturnType<typeof setInterval> | undefined;
        if (status !== InteractionStatus.IDLE && status !== InteractionStatus.SLEEPING) {
            blinkInterval = setInterval(() => {
                setIsBlinking(true);
                setTimeout(() => setIsBlinking(false), 150);
            }, Math.random() * 4000 + 3000);
        }
        return () => clearInterval(blinkInterval);
    }, [status]);

    const eyeColor = status === InteractionStatus.ERROR ? "var(--error)" : color;

    if (status === InteractionStatus.IDLE || status === InteractionStatus.SLEEPING) {
        return (
            <g>
                <path d="M 115 152 Q 125 158 135 152" stroke={eyeColor} strokeWidth="2" fill="none" />
                <path d="M 185 152 Q 195 158 205 152" stroke={eyeColor} strokeWidth="2" fill="none" />
            </g>
        );
    }
    
    if (isBlinking && status !== InteractionStatus.AWAKENING) {
         return (
             <g>
                <path d={`M ${eyeX.left - 10} 150 L ${eyeX.left + 10} 150`} stroke={eyeColor} strokeWidth="2.5" className="transition-all" style={{ transitionProperty: 'd', transitionDuration: eyeTransitionDuration }} />
                <path d={`M ${eyeX.right - 10} 150 L ${eyeX.right + 10} 150`} stroke={eyeColor} strokeWidth="2.5" className="transition-all" style={{ transitionProperty: 'd', transitionDuration: eyeTransitionDuration }} />
            </g>
        );
    }

    return (
        <g>
            <circle cx={eyeX.left} cy="150" r="5" fill={eyeColor} className="transition-all" style={{ transitionProperty: 'cx', transitionDuration: eyeTransitionDuration }}/>
            <circle cx={eyeX.right} cy="150" r="5" fill={eyeColor} className="transition-all" style={{ transitionProperty: 'cx', transitionDuration: eyeTransitionDuration }}/>
        </g>
    );
};

const FaceGlasses: React.FC = () => {
    return (
        <g 
            stroke="var(--text-secondary)" 
            strokeWidth="2.5" 
            fill="none" 
            className="glasses"
        >
            <circle cx="125" cy="150" r="18" />
            <circle cx="195" cy="150" r="18" />
            <path d="M 143 150 C 155 145, 165 145, 177 150" />
        </g>
    );
};

const FaceHeadphones: React.FC<{ color: string }> = ({ color }) => (
    <g stroke={color} fill="none" className="glasses">
        <path d="M80 160 A 80 80 0 0 1 240 160" strokeWidth="12" />
        <path d="M80 160 v -20 a 10 10 0 0 1 10 -10 h 10 a 10 10 0 0 1 10 10 v 40 a 10 10 0 0 1 -10 10 h -10 a 10 10 0 0 1 -10 -10 z" strokeWidth="4" fill={`${color}33`} />
        <path d="M240 160 v -20 a 10 10 0 0 0 -10 -10 h -10 a 10 10 0 0 0 -10 10 v 40 a 10 10 0 0 0 10 10 h 10 a 10 10 0 0 0 10 -10 z" strokeWidth="4" fill={`${color}33`} />
    </g>
);


const FaceHat: React.FC<{ color: string }> = ({ color }) => (
    <g transform="translate(0 -65) rotate(-10 160 160)" className="glasses">
        <path d="M110,95 h100 a5,5 0 0 1 5,5 v5 H105 v-5 a5,5 0 0 1 5,-5 z" fill="var(--text-secondary)" stroke="none" />
        <path d="M120,95 v-30 a40,40 0 0 1 40,0 v30" fill={color} stroke="none" />
    </g>
);


const Blush: React.FC<{ color: string }> = ({ color }) => (
    <g className="blush-cheeks">
        <circle cx="110" cy="175" r="15" fill={color} opacity="0.1" />
        <circle cx="210" cy="175" r="15" fill={color} opacity="0.1" />
    </g>
);

export const AsclepioFace: React.FC<AsclepioFaceProps> = ({ status, isBoardVisible, customization }) => {
  const isThinking = status === InteractionStatus.THINKING;
  const isSpeaking = status === InteractionStatus.SPEAKING;
  const isError = status === InteractionStatus.ERROR;
  const isIdle = status === InteractionStatus.IDLE || status === InteractionStatus.SLEEPING;

  const glowStyle = useMemo(() => ({
    filter: isThinking
      ? `drop-shadow(0 0 25px var(--thinking-glow))`
      : isSpeaking
      ? `drop-shadow(0 0 20px ${customization.color}99)`
      : isError
      ? `drop-shadow(0 0 20px var(--error-glow))`
      : `drop-shadow(0 0 12px ${customization.color}77)`,
  }), [isThinking, isSpeaking, isError, customization.color]);

  const mainContainerClasses = useMemo(() => {
      let classes = "transition-all duration-500 ease-in-out";
      if (isIdle) {
          classes += ' animate-idle-face';
      } else if (isSpeaking) {
          classes += ' animate-speaking-face';
      }
      return classes;
  }, [isIdle, isSpeaking]);
  
  const faceAccentColor = isError ? "var(--error)" : customization.color;

  return (
    <div style={glowStyle} className={mainContainerClasses}>
      <svg width="320" height="320" viewBox="0 0 320 320" className="w-60 h-60 sm:w-72 sm:h-72">
        <defs>
            <radialGradient id="faceGradient" cx="0.5" cy="0.5" r="0.5">
                <stop offset="0%" stopColor={isError ? "rgba(217, 48, 37, 0.08)" : `${customization.color}14`} />
                <stop offset="100%" stopColor={isError ? "rgba(217, 48, 37, 0.01)" : `${customization.color}03`} />
            </radialGradient>
        </defs>
        
        {customization.accessory === 'hat' && <FaceHat color={customization.color} />}
        
        <circle 
            cx="160" 
            cy="160" 
            r="100" 
            stroke={faceAccentColor} 
            strokeOpacity={isError ? 0.8 : (isIdle ? 0.3 : 0.6)}
            strokeWidth={customization.strokeWidth}
            fill="url(#faceGradient)" 
            className="transition-all duration-500" />
        
        {isThinking && <Blush color={customization.color} />}
        <Eyes status={status} isBoardVisible={isBoardVisible} color={customization.color} />
        <Mouth status={status} color={customization.color} />
        {customization.accessory === 'glasses' && <FaceGlasses />}
        {customization.accessory === 'headphones' && <FaceHeadphones color={customization.color} />}
      </svg>
    </div>
  );
};