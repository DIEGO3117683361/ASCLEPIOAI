
import React, { useState } from 'react';
import { CheckIcon } from '../icons/CheckIcon.tsx';
import { CloseIcon } from '../icons/CloseIcon.tsx';


interface QuizOption {
    text: string;
    explanation: string;
}

interface QuizData {
    question: string;
    options: QuizOption[];
    correctOptionIndex: number;
}


export const QuizView: React.FC<{ data: QuizData }> = ({ data }) => {
    const [selection, setSelection] = useState<{ index: number; isCorrect: boolean } | null>(null);

    const handleSelect = (index: number) => {
        if (selection) return; // Prevent changing answer
        setSelection({
            index: index,
            isCorrect: index === data.correctOptionIndex,
        });
    };
    
    const getOptionStyle = (index: number) => {
        if (!selection) {
            return "bg-[var(--accent-light)]/[0.3] hover:bg-[var(--accent-light)]/[0.6] border-transparent";
        }

        const isSelected = selection.index === index;
        const isCorrect = index === data.correctOptionIndex;
        
        if (isSelected) {
            return selection.isCorrect 
                ? "bg-green-500/30 border-green-500 text-[var(--text-primary)]" 
                : "bg-red-500/30 border-red-500 text-[var(--text-primary)]";
        }
        
        if (isCorrect) {
             return "bg-green-500/20 border-green-500/50 text-[var(--text-secondary)]";
        }

        return "bg-transparent border-transparent text-[var(--text-secondary)] opacity-70";
    };

    const getIcon = (index: number) => {
        if (!selection || selection.index !== index) return null;
        return selection.isCorrect ? <CheckIcon className="w-5 h-5 text-green-500" /> : <CloseIcon className="w-5 h-5 text-red-500" />;
    }

    if (!data || !data.question || !data.options) {
         return <div className="text-[var(--text-secondary)]">No se pudo cargar el cuestionario.</div>;
    }

    return (
        <div className="flex flex-col gap-4 p-2 text-[var(--text-primary)]">
            <h3 className="text-xl font-semibold text-center">{data.question}</h3>
            <div className="flex flex-col gap-3">
                {data.options.map((option, index) => (
                    <button
                        key={index}
                        onClick={() => handleSelect(index)}
                        disabled={!!selection}
                        className={`w-full text-left p-3 rounded-lg border transition-all duration-300 flex justify-between items-center ${getOptionStyle(index)}`}
                    >
                       <span>{option.text}</span>
                       {getIcon(index)}
                    </button>
                ))}
            </div>

            {selection && (
                <div className={`p-3 rounded-lg animate-fade-in mt-2 ${selection.isCorrect ? 'bg-green-500/10' : 'bg-red-500/10'}`}>
                    <h4 className={`font-bold ${selection.isCorrect ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'}`}>
                        {selection.isCorrect ? '¡Correcto!' : 'Incorrecto'}
                    </h4>
                    <p className="text-sm text-[var(--text-secondary)] mt-1">{data.options[selection.index].explanation}</p>
                </div>
            )}
        </div>
    );
};