
import React, { useState } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { DownloadIcon } from '../icons/DownloadIcon.tsx';

interface DocumentData {
    title: string;
    htmlContent: string;
}

export const DocumentView: React.FC<{ data: DocumentData }> = ({ data }) => {
    const [isDownloading, setIsDownloading] = useState(false);

    const handleDownloadPdf = () => {
        setIsDownloading(true);
        const input = document.getElementById('pdf-content');
        if (!input) {
            setIsDownloading(false);
            return;
        }

        html2canvas(input, {
            scale: 2, // Higher scale for better quality
            useCORS: true,
            backgroundColor: null, // Use element's background
        }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF({
                orientation: 'portrait',
                unit: 'px',
                format: 'a4',
            });
            
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = pdf.internal.pageSize.getHeight();
            const canvasWidth = canvas.width;
            const canvasHeight = canvas.height;
            const ratio = canvasWidth / canvasHeight;

            let imgWidth = pdfWidth - 20; // with margin
            let imgHeight = imgWidth / ratio;
            
            let heightLeft = imgHeight;
            let position = 10; // top margin
            
            pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
            heightLeft -= pdfHeight;

            while (heightLeft >= 0) {
              position = heightLeft - imgHeight + 10;
              pdf.addPage();
              pdf.addImage(imgData, 'PNG', 10, position, imgWidth, imgHeight);
              heightLeft -= pdfHeight;
            }
            
            const fileName = data.title.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '-').substring(0, 50) || 'asclepio-document';
            pdf.save(`${fileName}.pdf`);
            setIsDownloading(false);
        }).catch(err => {
            console.error("Could not generate PDF", err);
            setIsDownloading(false);
        });
    };

    return (
        <div className="relative p-2">
            <button
                onClick={handleDownloadPdf}
                disabled={isDownloading}
                className="absolute -top-2 -right-2 p-1.5 bg-[var(--accent-light)]/[0.7] hover:bg-[var(--accent-light)] text-[var(--accent)] rounded-full transition-all z-10"
                aria-label="Descargar como PDF"
            >
                <DownloadIcon className="w-5 h-5" />
            </button>
            <div id="pdf-content" className="bg-transparent text-[var(--text-primary)]">
                <div 
                    className="text-base sm:text-lg font-light leading-relaxed whitespace-pre-wrap highlightable-content"
                    dangerouslySetInnerHTML={{ __html: data.htmlContent }}
                />
            </div>
             {isDownloading && <div className="absolute inset-0 bg-black/10 flex items-center justify-center rounded-lg text-sm text-[var(--text-primary)]">Generando PDF...</div>}
        </div>
    );
};