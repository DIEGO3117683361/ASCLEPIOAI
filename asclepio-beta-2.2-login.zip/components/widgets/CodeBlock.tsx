
import React, { useState, useEffect } from 'react';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import oneDark from 'react-syntax-highlighter/dist/esm/styles/prism/one-dark.js';
import oneLight from 'react-syntax-highlighter/dist/esm/styles/prism/one-light.js';
import { CopyIcon } from '../icons/CopyIcon.tsx';
import { CheckIcon } from '../icons/CheckIcon.tsx';
import { Theme } from '../../types.ts';

interface CodeBlockProps {
  language: string;
  code: string;
  theme: Theme;
}

export const CodeBlock: React.FC<CodeBlockProps> = ({ language, code, theme }) => {
    const [isCopied, setIsCopied] = useState(false);
    
    const handleCopy = () => {
        navigator.clipboard.writeText(code).then(() => {
            setIsCopied(true);
        });
    };

    useEffect(() => {
        if (isCopied) {
            const timer = setTimeout(() => {
                setIsCopied(false);
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [isCopied]);

    const style = theme === 'dark' ? oneDark : oneLight;

    return (
        <div className="relative w-full text-sm rounded-lg overflow-hidden group">
            <button
                onClick={handleCopy}
                className="absolute top-2 right-2 p-1.5 bg-gray-500/20 hover:bg-gray-500/40 text-[var(--text-secondary)] hover:text-[var(--text-primary)] rounded-md transition-all opacity-0 group-hover:opacity-100 focus:opacity-100 z-10"
                aria-label="Copiar código"
            >
                {isCopied ? <CheckIcon className="w-5 h-5 text-green-400" /> : <CopyIcon className="w-5 h-5" />}
            </button>
            <SyntaxHighlighter
                language={language}
                style={style}
                customStyle={{
                    margin: 0,
                    padding: '1.25rem',
                    width: '100%',
                    backgroundColor: 'transparent'
                }}
                codeTagProps={{
                    style: {
                        fontFamily: '"Fira Code", monospace',
                        fontSize: '0.9rem',
                    },
                }}
                showLineNumbers
                className="custom-scrollbar"
            >
                {code}
            </SyntaxHighlighter>
        </div>
    );
};