import React from 'react';

interface Position {
    fret: number;
    string: number;
    finger: number;
}

interface GuitarData {
    chordName: string;
    frets: [number, number]; // e.g., [1, 3] to show frets 1 to 3
    positions: Position[];
}

const STRING_COUNT = 6;
const FRET_WIDTH = 80;
const STRING_SPACING = 30;
const FRETBOARD_PADDING = 30;
const NECK_WIDTH = STRING_SPACING * (STRING_COUNT - 1);

export const GuitarFretboard: React.FC<{ data: GuitarData }> = ({ data }) => {
    if (!data || !data.frets || !data.positions) {
        return <div className="text-[var(--error)]">Datos de guitarra no válidos.</div>;
    }
    const { chordName, frets, positions } = data;
    const [startFret, endFret] = frets;
    const fretCount = endFret - startFret + 1;

    const viewBoxWidth = FRET_WIDTH * fretCount + FRETBOARD_PADDING * 2;
    const viewBoxHeight = NECK_WIDTH + FRETBOARD_PADDING * 2 + 30; // Extra space for fret numbers

    return (
        <div className="flex flex-col items-center justify-center w-full h-full text-[var(--text-primary)]">
            <h3 className="text-2xl font-bold mb-4">{chordName}</h3>
            <svg viewBox={`0 0 ${viewBoxWidth} ${viewBoxHeight}`} width="100%" height="90%" aria-label={`Diagrama de acordes de guitarra para ${chordName}`}>
                <g transform={`translate(${FRETBOARD_PADDING}, ${FRETBOARD_PADDING})`}>
                    {/* Frets */}
                    {[...Array(fretCount + 1)].map((_, i) => (
                        <line
                            key={`fret-${i}`}
                            x1={i * FRET_WIDTH}
                            y1={0}
                            x2={i * FRET_WIDTH}
                            y2={NECK_WIDTH}
                            stroke={i === 0 && startFret === 1 ? 'var(--text-primary)' : 'var(--text-secondary)'}
                            strokeWidth={i === 0 && startFret === 1 ? "3" : "1.5"}
                        />
                    ))}
                     {/* Fret Numbers */}
                    {[...Array(fretCount)].map((_, i) => {
                         const fretNumber = startFret + i;
                         if (fretNumber % 2 !== 0 && fretNumber < 10 && fretNumber > 1) { // common inlay positions
                            return <text key={`fret-num-${i}`} x={(i + 0.5) * FRET_WIDTH} y={NECK_WIDTH + 25} textAnchor="middle" fill="var(--text-secondary)" fontSize="14">{fretNumber}</text>
                         }
                         return null;
                    })}

                    {/* Strings */}
                    {[...Array(STRING_COUNT)].map((_, i) => (
                        <line
                            key={`string-${i}`}
                            x1={0}
                            y1={i * STRING_SPACING}
                            x2={FRET_WIDTH * fretCount}
                            y2={i * STRING_SPACING}
                            stroke="var(--text-secondary)"
                            strokeWidth="1"
                        />
                    ))}

                    {/* Finger Positions */}
                    {positions.map(({ fret, string, finger }, i) => {
                        const fretIndex = fret - startFret;
                        const x = (fretIndex + 0.5) * FRET_WIDTH;
                        const y = (STRING_COUNT - string) * STRING_SPACING;
                        return (
                            <g key={`pos-${i}`}>
                                <circle cx={x} cy={y} r={STRING_SPACING / 2.2} fill="var(--accent)" />
                                <text x={x} y={y + 5} textAnchor="middle" fill="var(--background)" fontWeight="bold" fontSize="16">{finger}</text>
                            </g>
                        );
                    })}
                </g>
            </svg>
        </div>
    );
};