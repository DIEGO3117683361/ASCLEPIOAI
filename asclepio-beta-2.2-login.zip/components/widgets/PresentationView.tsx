
import React, { useState } from 'react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { DownloadIcon } from '../icons/DownloadIcon.tsx';

interface Slide {
    id: string;
    title: string;
    htmlContent: string;
}

interface PresentationData {
    title: string;
    slides: Slide[];
}

export const PresentationView: React.FC<{ data: PresentationData }> = ({ data }) => {
    const [isDownloading, setIsDownloading] = useState(false);

    const handleDownloadPdf = async () => {
        setIsDownloading(true);
        const slideElements = Array.from(document.querySelectorAll<HTMLElement>('.slide-item'));
        if (slideElements.length === 0) {
            setIsDownloading(false);
            return;
        }

        const pdf = new jsPDF({
            orientation: 'landscape',
            unit: 'px',
            // A common 16:9 presentation format
            format: [slideElements[0].offsetWidth, slideElements[0].offsetHeight],
        });

        const theme = document.documentElement.classList.contains('dark') ? 'dark' : 'light';
        const backgroundColor = theme === 'dark' ? '#000000' : '#ffffff';

        for (let i = 0; i < slideElements.length; i++) {
            const element = slideElements[i];
            try {
                const canvas = await html2canvas(element, {
                    scale: 2,
                    useCORS: true,
                    backgroundColor: backgroundColor,
                    logging: false,
                });

                const imgData = canvas.toDataURL('image/png');
                const pdfWidth = pdf.internal.pageSize.getWidth();
                const pdfHeight = pdf.internal.pageSize.getHeight();

                if (i > 0) {
                    pdf.addPage([pdfWidth, pdfHeight], 'landscape');
                }
                pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);

            } catch(err) {
                console.error(`Error converting slide ${i} to canvas:`, err)
            }
        }
        
        const fileName = data.title.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s+/g, '-').substring(0, 50) || 'asclepio-presentation';
        pdf.save(`${fileName}.pdf`);
        setIsDownloading(false);
    };

    if (!data || !data.slides || data.slides.length === 0) {
        return <div className="text-[var(--text-secondary)]">No se pudo cargar la presentación.</div>;
    }

    return (
        <div className="relative p-1">
            <div className="flex justify-between items-center mb-4 px-1">
                <h2 className="text-2xl sm:text-3xl font-bold text-[var(--text-primary)]">{data.title}</h2>
                <button
                    onClick={handleDownloadPdf}
                    disabled={isDownloading}
                    className="p-2 bg-[var(--accent-light)]/[0.7] hover:bg-[var(--accent-light)] text-[var(--accent)] rounded-full transition-all disabled:opacity-50 disabled:cursor-wait"
                    aria-label="Descargar presentación como PDF"
                >
                    <DownloadIcon className="w-5 h-5" />
                </button>
            </div>
            <div id="presentation-content" className="flex flex-col gap-6">
                {data.slides.map((slide) => (
                    <div
                        key={slide.id}
                        id={slide.id}
                        className="slide-item p-6 rounded-lg border border-[var(--border-color)] bg-[var(--background)] aspect-video flex flex-col justify-center highlightable-content"
                    >
                        <h3 className="text-xl sm:text-2xl font-semibold mb-3 text-[var(--text-primary)]">{slide.title}</h3>
                        <div
                            className="text-base sm:text-lg font-light leading-relaxed text-[var(--text-secondary)] prose dark:prose-invert"
                            dangerouslySetInnerHTML={{ __html: slide.htmlContent }}
                        />
                    </div>
                ))}
            </div>
            {isDownloading && (
                <div className="absolute inset-0 bg-black/20 backdrop-blur-sm flex items-center justify-center rounded-lg text-sm text-[var(--text-primary)] z-10">
                    <p className="bg-[var(--background)] px-4 py-2 rounded-lg shadow-lg">Generando PDF...</p>
                </div>
            )}
        </div>
    );
};