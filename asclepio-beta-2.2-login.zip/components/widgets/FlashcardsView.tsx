
import React, { useState } from 'react';
import { FlipIcon } from '../icons/FlipIcon.tsx';

interface Card {
    question: string;
    answer: string;
}

interface FlashcardsData {
    cards: Card[];
}

const Flashcard: React.FC<{ card: Card }> = ({ card }) => {
    const [isFlipped, setIsFlipped] = useState(false);

    return (
        <div 
            className="w-full h-48 [perspective:1000px] group"
            onClick={() => setIsFlipped(!isFlipped)}
        >
            <div
                className={`relative w-full h-full text-center transition-transform duration-700 [transform-style:preserve-3d] ${isFlipped ? '[transform:rotateY(180deg)]' : ''}`}
            >
                {/* Front */}
                <div className="absolute w-full h-full p-4 flex flex-col items-center justify-center bg-[var(--accent-light)]/[0.4] border border-[var(--border-color)] rounded-xl [backface-visibility:hidden]">
                    <p className="text-lg font-medium text-[var(--text-primary)]">{card.question}</p>
                    <div className="absolute bottom-3 right-3 flex items-center gap-1 text-xs text-[var(--text-secondary)] opacity-60 group-hover:opacity-100 transition-opacity">
                        <FlipIcon className="w-3 h-3"/>
                        <span>Girar</span>
                    </div>
                </div>
                {/* Back */}
                <div className="absolute w-full h-full p-4 flex items-center justify-center bg-[var(--accent-light)]/[0.7] border border-[var(--border-color)] rounded-xl [transform:rotateY(180deg)] [backface-visibility:hidden]">
                    <p className="text-lg font-semibold text-[var(--accent)]">{card.answer}</p>
                </div>
            </div>
        </div>
    );
};

export const FlashcardsView: React.FC<{ data: FlashcardsData }> = ({ data }) => {
    if (!data || !data.cards || data.cards.length === 0) {
        return <div className="text-[var(--text-secondary)]">No se pudieron cargar las tarjetas.</div>;
    }

    return (
        <div className="flex flex-col gap-4 p-2">
            <h3 className="text-xl font-bold text-center mb-2 text-[var(--text-primary)]">Tarjetas de Estudio</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {data.cards.map((card, index) => (
                    <Flashcard key={index} card={card} />
                ))}
            </div>
        </div>
    );
};