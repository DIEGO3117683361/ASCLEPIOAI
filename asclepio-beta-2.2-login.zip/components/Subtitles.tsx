import React from 'react';

interface SubtitlesProps {
  text: string | null;
}

export const Subtitles: React.FC<SubtitlesProps> = ({ text }) => {
  if (!text) {
    return null;
  }

  return (
    <div className="subtitles">
      {text}
    </div>
  );
};
