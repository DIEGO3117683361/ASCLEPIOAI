
import React from 'react';
import { ChatBubbleIcon } from './icons/ChatBubbleIcon.tsx';
import { SparklesIcon } from './icons/SparklesIcon.tsx';
import { PresentationIcon } from './icons/PresentationIcon.tsx';
import { SlidersIcon } from './icons/SlidersIcon.tsx';

interface InfoCardProps {
    icon: React.ReactNode;
    title: string;
    description: string;
    animationDelay: string;
}

const InfoCard: React.FC<InfoCardProps> = ({ icon, title, description, animationDelay }) => (
    <div className="info-card" style={{ animationDelay }}>
        <div className="info-card-icon">{icon}</div>
        <h3>{title}</h3>
        <p>{description}</p>
    </div>
);

const features = [
    {
        icon: <ChatBubbleIcon className="w-5 h-5" />,
        title: "Conversación Inteligente",
        description: "Dialoga de forma natural. Asclepio comprende el contexto para ofrecerte respuestas coherentes y útiles.",
    },
    {
        icon: <SparklesIcon className="w-5 h-5" />,
        title: "Creatividad sin Límites",
        description: "Pide que genere imágenes, cree cuestionarios, resuma textos, escriba código y hasta prepare presentaciones.",
    },
    {
        icon: <PresentationIcon className="w-5 h-5" />,
        title: "Modo Presentación",
        description: "Transforma cualquier explicación en una presentación visual. Ideal para aprender y exponer ideas de forma clara.",
    },
    {
        icon: <SlidersIcon className="w-5 h-5" />,
        title: "Tu Asistente Personal",
        description: "Adapta la experiencia. Configura la voz, el tema y comparte tus intereses para respuestas más personalizadas.",
    },
];

export const WelcomeScreen: React.FC = () => {
    return (
        <div className="absolute inset-0 flex items-center justify-between p-8 lg:p-16 pointer-events-none welcome-screen-container">
            {/* Left Column */}
            <div className="flex flex-col gap-6">
                <InfoCard {...features[0]} animationDelay="0.2s" />
                <InfoCard {...features[1]} animationDelay="0.4s" />
            </div>
            {/* Right Column */}
            <div className="flex flex-col gap-6">
                <InfoCard {...features[2]} animationDelay="0.3s" />
                <InfoCard {...features[3]} animationDelay="0.5s" />
            </div>
        </div>
    );
};