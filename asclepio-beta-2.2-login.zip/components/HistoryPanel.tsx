import React from 'react';
import { ConversationSession } from '../types.ts';
import { CloseIcon } from './icons/CloseIcon.tsx';
import { TrashIcon } from './icons/TrashIcon.tsx';

interface HistoryPanelProps {
  isOpen: boolean;
  onClose: () => void;
  history: ConversationSession[];
  onSelectSession: (session: ConversationSession) => void;
  onClearHistory: () => void;
}

export const HistoryPanel: React.FC<HistoryPanelProps> = ({ isOpen, onClose, history, onSelectSession, onClearHistory }) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 flex justify-end animate-fade-in" onClick={onClose}>
            <div 
                className="bg-[var(--control-bg)] backdrop-blur-xl w-11/12 max-w-sm h-full shadow-2xl border-l border-[var(--border-color)] flex flex-col"
                onClick={e => e.stopPropagation()}
            >
                <header className="flex items-center justify-between p-4 border-b border-[var(--border-color)]">
                    <h2 className="text-xl font-bold">Historial</h2>
                    <button onClick={onClose} className="p-1 rounded-full text-[var(--text-secondary)] hover:bg-[var(--accent-light)] transition-colors">
                       <CloseIcon className="w-5 h-5" />
                    </button>
                </header>

                <div className="flex-1 overflow-y-auto custom-scrollbar">
                    {history.length === 0 ? (
                        <div className="text-center text-[var(--text-secondary)] p-8">
                            No hay conversaciones guardadas.
                        </div>
                    ) : (
                        <ul>
                            {history.map(session => (
                                <li key={session.id}>
                                    <button 
                                        onClick={() => onSelectSession(session)}
                                        className="w-full text-left p-4 hover:bg-[var(--accent-light)] transition-colors border-b border-[var(--border-color)]"
                                    >
                                        <p className="font-medium text-[var(--text-primary)] truncate">{session.title}</p>
                                        <p className="text-sm text-[var(--text-secondary)] mt-1">
                                            {new Date(session.startTime).toLocaleString()}
                                        </p>
                                    </button>
                                </li>
                            ))}
                        </ul>
                    )}
                </div>

                {history.length > 0 && (
                    <footer className="p-4 border-t border-[var(--border-color)]">
                        <button 
                            onClick={onClearHistory}
                            className="w-full flex items-center justify-center gap-2 px-4 py-2 text-sm text-[var(--error)] bg-red-500/10 dark:bg-red-500/20 rounded-lg hover:bg-red-500/20 dark:hover:bg-red-500/30 transition-colors"
                        >
                            <TrashIcon className="w-4 h-4" />
                            <span>Borrar Historial</span>
                        </button>
                    </footer>
                )}
            </div>
        </div>
    );
};