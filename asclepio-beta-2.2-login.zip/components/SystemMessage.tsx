
import React from 'react';
import { InteractionStatus } from '../types.ts';

interface SystemMessageProps {
  status: InteractionStatus;
  error: string | null;
  onStart: () => void;
}

const MessageDisplay: React.FC<{ text: string; isError?: boolean }> = ({ text, isError = false }) => (
    <p className={`text-lg text-center font-light tracking-wide animate-pulse ${isError ? 'text-[var(--error)]' : 'text-[var(--text-secondary)]'}`}>{text}</p>
);

export const SystemMessage: React.FC<SystemMessageProps> = ({ status, error, onStart }) => {
  const renderContent = () => {
    switch (status) {
      case InteractionStatus.IDLE:
        return (
          <button
            onClick={onStart}
            className="px-8 py-3 bg-[var(--accent)] text-white rounded-xl transition-all duration-300 text-lg font-medium shadow-lg shadow-[var(--accent-glow)] hover:shadow-xl hover:shadow-[var(--accent-glow)] transform hover:-translate-y-0.5"
          >
            Comenzar Diálogo
          </button>
        );
      case InteractionStatus.INITIALIZING:
        return <MessageDisplay text="Iniciando sistema..." />;
      case InteractionStatus.AWAKENING:
        return <MessageDisplay text="Despertando..." />;
      case InteractionStatus.SLEEPING:
        return <MessageDisplay text="Descansando..." />;
      case InteractionStatus.LISTENING:
        return <MessageDisplay text="Escuchando..." />;
      case InteractionStatus.THINKING:
        return <MessageDisplay text="Pensando..." />;
      case InteractionStatus.SPEAKING:
          return <MessageDisplay text="Hablando..." />;
      case InteractionStatus.AWAITING_CONTINUATION:
          return <MessageDisplay text="Escuchando..." />;
      case InteractionStatus.ERROR:
        return (
          <div className="text-center animate-fade-in flex flex-col items-center gap-3">
            <p className="text-lg text-[var(--error)]">{error || 'Ha ocurrido un error inesperado.'}</p>
            <button
                onClick={onStart}
                className="px-6 py-2 bg-[var(--error)]/20 text-[var(--error)] border border-[var(--error)]/50 rounded-lg hover:bg-[var(--error)]/30 transition-colors"
            >
                Intentar de Nuevo
            </button>
          </div>
        );
      default:
        return null;
    }
  };

  return <div className="h-24 flex items-center justify-center mt-4">{renderContent()}</div>;
};