import React, { useState, useEffect, useLayoutEffect } from 'react';
import ReactDOM from 'react-dom/client';

export interface TutorialStep {
    id: string;
    text: string;
    position: 'top' | 'bottom' | 'left' | 'right';
}

interface TutorialGuideProps {
    steps: TutorialStep[];
    currentStep: number;
    onNext: () => void;
    onEnd: () => void;
}

interface ElementPosition {
    top: number;
    left: number;
    width: number;
    height: number;
}

const getPopoverPosition = (elemRect: ElementPosition, popoverRect: DOMRect, position: TutorialStep['position']) => {
    const margin = 12; // space between element and popover
    switch(position) {
        case 'top':
            return {
                top: elemRect.top - popoverRect.height - margin,
                left: elemRect.left + elemRect.width / 2 - popoverRect.width / 2,
            };
        case 'left':
             return {
                top: elemRect.top + elemRect.height / 2 - popoverRect.height / 2,
                left: elemRect.left - popoverRect.width - margin,
            };
        case 'right':
            return {
                top: elemRect.top + elemRect.height / 2 - popoverRect.height / 2,
                left: elemRect.left + elemRect.width + margin,
            };
        case 'bottom':
        default:
            return {
                top: elemRect.top + elemRect.height + margin,
                left: elemRect.left + elemRect.width / 2 - popoverRect.width / 2,
            };
    }
};

export const TutorialGuide: React.FC<TutorialGuideProps> = ({ steps, currentStep, onNext, onEnd }) => {
    const [elementPos, setElementPos] = useState<ElementPosition | null>(null);
    const popoverRef = React.useRef<HTMLDivElement>(null);
    
    const step = steps[currentStep];

    // Using useLayoutEffect to prevent flicker when positioning elements
    useLayoutEffect(() => {
        if (!step) {
            setElementPos(null);
            return;
        }

        const element = document.querySelector(`[data-tutorial-id="${step.id}"]`);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
            // Timeout to wait for scroll to finish
            const timer = setTimeout(() => {
                const rect = element.getBoundingClientRect();
                setElementPos({
                    top: rect.top,
                    left: rect.left,
                    width: rect.width,
                    height: rect.height,
                });
            }, 300);
            return () => clearTimeout(timer);
        } else {
             // If element is not found, skip to the next step
             onNext();
        }

    }, [currentStep, step, onNext]);

    if (!elementPos || !step) {
        return <div className="tutorial-overlay animate-fade-in" />;
    }

    const popoverRect = popoverRef.current?.getBoundingClientRect();
    const popoverPos = popoverRect ? getPopoverPosition(elementPos, popoverRect, step.position) : { top: 0, left: 0 };
    
    const isLastStep = currentStep === steps.length - 1;

    return (
        <div className="tutorial-overlay animate-fade-in">
            <div className="tutorial-highlight" style={{ ...elementPos, borderRadius: step.id === 'settings-button' ? '9999px' : '9999px' }} />
            <div 
                ref={popoverRef}
                className={`tutorial-popover pos-${step.position}`}
                style={popoverPos}
            >
                <p className="text-sm leading-relaxed mb-4 text-[var(--text-secondary)]">{step.text}</p>
                <div className="flex justify-between items-center">
                    <span className="text-xs text-[var(--text-secondary)]">{`${currentStep + 1} / ${steps.length}`}</span>
                    <button 
                        onClick={isLastStep ? onEnd : onNext}
                        className="px-4 py-1.5 bg-[var(--accent)] text-white text-sm rounded-lg hover:opacity-90 transition-opacity"
                    >
                        {isLastStep ? 'Finalizar' : 'Siguiente'}
                    </button>
                </div>
            </div>
        </div>
    );
};
