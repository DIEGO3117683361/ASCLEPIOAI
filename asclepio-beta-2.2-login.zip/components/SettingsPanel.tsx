import React from 'react';
import { Settings, BackgroundSetting, FaceCustomization } from '../types.ts';
import { CloseIcon } from './icons/CloseIcon.tsx';
import { InfoIcon } from './icons/InfoIcon.tsx';
import { CheckIcon } from './icons/CheckIcon.tsx';
import { NoAccessoryIcon } from './icons/NoAccessoryIcon.tsx';
import { GlassesIcon } from './icons/GlassesIcon.tsx';
import { HeadphonesIcon } from './icons/HeadphonesIcon.tsx';
import { HatIcon } from './icons/HatIcon.tsx';


interface SettingsPanelProps {
  isOpen: boolean;
  onClose: () => void;
  settings: Settings;
  onSettingsChange: (newSettings: Partial<Settings>) => void;
  voices: Settings['voice'][];
  onStartTutorial: () => void;
}

const FormRow: React.FC<{ label: string; children: React.ReactNode, direction?: 'col' | 'row' }> = ({ label, children, direction = 'row' }) => (
    <div className={`flex ${direction === 'col' ? 'flex-col items-start gap-2' : 'flex-col sm:flex-row sm:items-center sm:justify-between gap-2'} mb-4`}>
        <label className="text-[var(--text-secondary)] font-medium text-sm">{label}</label>
        {children}
    </div>
);

const Toggle: React.FC<{ checked: boolean; onChange: () => void; }> = ({ checked, onChange }) => (
    <button
        onClick={onChange}
        className={`w-12 h-6 rounded-full p-1 flex items-center transition-colors ${checked ? 'bg-[var(--accent)]' : 'bg-gray-300 dark:bg-gray-700'}`}
    >
        <span className={`w-4 h-4 bg-white rounded-full shadow-md transform transition-transform ${checked ? 'translate-x-6' : 'translate-x-0'}`} />
    </button>
);

const TextInput: React.FC<React.InputHTMLAttributes<HTMLInputElement>> = (props) => (
    <input
        {...props}
        className="w-full sm:w-2/3 bg-transparent text-[var(--text-primary)] rounded-lg px-3 py-2 border border-[var(--border-color)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-[var(--accent)] transition-colors duration-200"
    />
);

const TextArea: React.FC<React.TextareaHTMLAttributes<HTMLTextAreaElement>> = (props) => (
     <textarea
        {...props}
        rows={3}
        className="w-full sm:w-2/3 bg-transparent text-[var(--text-primary)] rounded-lg px-3 py-2 border border-[var(--border-color)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-[var(--accent)] transition-colors duration-200"
    />
);

const presetImages = [
    { name: 'Atardecer', url: 'https://images.pexels.com/photos/3225517/pexels-photo-3225517.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    { name: 'Nevada', url: 'https://images.pexels.com/photos/1450082/pexels-photo-1450082.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
    { name: 'Volcán', url: 'https://images.pexels.com/photos/3761118/pexels-photo-3761118.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2' },
];

const AccessoryButton: React.FC<{
    label: string;
    onClick: () => void;
    isActive: boolean;
    children: React.ReactNode;
}> = ({ label, onClick, isActive, children }) => (
    <button
        onClick={onClick}
        aria-label={label}
        className={`flex flex-col items-center justify-center gap-1 w-20 h-20 rounded-lg border-2 transition-colors ${isActive ? 'border-[var(--accent)] bg-[var(--accent-light)]' : 'border-transparent hover:bg-gray-500/10'}`}
    >
        {children}
        <span className="text-xs text-[var(--text-secondary)]">{label}</span>
    </button>
);


export const SettingsPanel: React.FC<SettingsPanelProps> = ({ isOpen, onClose, settings, onSettingsChange, voices, onStartTutorial }) => {
    if (!isOpen) return null;

    const handleBackgroundChange = (setting: BackgroundSetting) => {
        if (setting.type === 'image') {
            setting.blur = settings.background.blur ?? 8;
        }
        onSettingsChange({ background: setting });
    };

    const handleBlurChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        onSettingsChange({
            background: {
                ...settings.background,
                type: 'image',
                blur: parseInt(e.target.value, 10),
            }
        });
    };

    const handleResetBlur = () => {
        onSettingsChange({
            background: {
                ...settings.background,
                type: 'image',
                blur: 8,
            }
        });
    };

    const handleVoiceChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const newVoice = voices.find(v => v.voiceURI === e.target.value);
        if (newVoice) {
            onSettingsChange({ voice: newVoice });
        }
    }
    
    const handleUserInfoChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        onSettingsChange({
            userInfo: {
                ...settings.userInfo,
                [e.target.name]: e.target.value,
            }
        });
    }

    const handleFaceChange = (change: Partial<FaceCustomization>) => {
        onSettingsChange({
            face: {
                ...settings.face,
                ...change,
            }
        });
    };

    const handleResetFace = () => {
        onSettingsChange({
            face: {
                accessory: 'none',
                color: settings.theme === 'dark' ? '#0a84ff' : '#007aff',
                strokeWidth: 1.5,
            }
        });
    };

    return (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm z-40 flex items-center justify-center animate-fade-in" onClick={onClose}>
            <div 
                className="bg-[var(--control-bg)] backdrop-blur-xl w-11/12 max-w-md max-h-[90vh] overflow-y-auto custom-scrollbar rounded-2xl shadow-2xl p-6 border border-[var(--border-color)] relative"
                onClick={e => e.stopPropagation()}
            >
                <button onClick={onClose} className="absolute top-4 right-4 p-1 rounded-full text-[var(--text-secondary)] hover:bg-[var(--accent-light)] transition-colors">
                   <CloseIcon className="w-5 h-5" />
                </button>
                <h2 className="text-xl font-bold mb-6">Ajustes</h2>
                
                <section>
                    <h3 className="font-semibold mb-3 text-sm uppercase text-[var(--text-secondary)]">Apariencia y Accesibilidad</h3>
                    <FormRow label="Tema">
                        <div className="flex items-center gap-4">
                             <span className="text-sm">Claro</span>
                             <Toggle checked={settings.theme === 'dark'} onChange={() => onSettingsChange({ theme: settings.theme === 'light' ? 'dark' : 'light' })} />
                             <span className="text-sm">Oscuro</span>
                        </div>
                    </FormRow>
                     <FormRow label="Mostrar Subtítulos">
                        <Toggle checked={settings.showSubtitles} onChange={() => onSettingsChange({ showSubtitles: !settings.showSubtitles })} />
                    </FormRow>
                </section>
                
                <div className="my-6 border-t border-[var(--border-color)]"></div>

                <section>
                    <div className="flex items-center justify-between mb-3">
                        <h3 className="font-semibold text-sm uppercase text-[var(--text-secondary)]">Personalizar Rostro</h3>
                        <button
                            onClick={handleResetFace}
                            className="text-xs text-[var(--text-secondary)] hover:text-[var(--accent)] transition-colors"
                        >
                            Restablecer
                        </button>
                    </div>
                    <FormRow label="Accesorio" direction="col">
                         <div className="flex items-center gap-2 flex-wrap">
                            <AccessoryButton label="Ninguno" onClick={() => handleFaceChange({ accessory: 'none' })} isActive={settings.face.accessory === 'none'}>
                                <NoAccessoryIcon className="w-7 h-7" />
                            </AccessoryButton>
                             <AccessoryButton label="Lentes" onClick={() => handleFaceChange({ accessory: 'glasses' })} isActive={settings.face.accessory === 'glasses'}>
                                <GlassesIcon className="w-7 h-7" />
                            </AccessoryButton>
                             <AccessoryButton label="Auriculares" onClick={() => handleFaceChange({ accessory: 'headphones' })} isActive={settings.face.accessory === 'headphones'}>
                                <HeadphonesIcon className="w-7 h-7" />
                            </AccessoryButton>
                             <AccessoryButton label="Sombrero" onClick={() => handleFaceChange({ accessory: 'hat' })} isActive={settings.face.accessory === 'hat'}>
                                <HatIcon className="w-7 h-7" />
                            </AccessoryButton>
                         </div>
                    </FormRow>
                     <FormRow label="Color de acento">
                        <input
                            type="color"
                            value={settings.face.color}
                            onChange={(e) => handleFaceChange({ color: e.target.value })}
                            className="w-12 h-10 p-1 bg-transparent border border-[var(--border-color)] rounded-lg cursor-pointer"
                        />
                     </FormRow>
                     <FormRow label="Grosor de línea">
                        <div className="w-full sm:w-2/3 flex items-center gap-3">
                            <input
                                type="range"
                                min="1"
                                max="5"
                                step="0.1"
                                value={settings.face.strokeWidth}
                                onChange={(e) => handleFaceChange({ strokeWidth: parseFloat(e.target.value) })}
                                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                                style={{ accentColor: 'var(--accent)'}}
                            />
                            <span className="text-sm font-mono w-12 text-center text-[var(--text-secondary)]">{settings.face.strokeWidth.toFixed(1)}</span>
                        </div>
                    </FormRow>
                </section>

                 <section className="mt-6">
                    <h3 className="font-semibold mb-3 text-sm uppercase text-[var(--text-secondary)]">Fondo de Espacio de Trabajo</h3>
                     <FormRow label="Elige un fondo" direction="col">
                         <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 w-full">
                            <button onClick={() => handleBackgroundChange({ type: 'default', value: ''})} className={`aspect-square rounded-lg border-2 flex items-center justify-center text-center text-xs p-1 ${settings.background.type === 'default' ? 'border-[var(--accent)]' : 'border-[var(--border-color)]'}`} style={{backgroundColor: 'var(--background)'}}>Básico</button>
                            {presetImages.map(img => (
                                <button key={img.url} onClick={() => handleBackgroundChange({ type: 'image', value: img.url })} className={`aspect-square rounded-lg border-2 bg-cover bg-center relative ${settings.background.type === 'image' && settings.background.value === img.url ? 'border-[var(--accent)]' : 'border-transparent'}`} style={{backgroundImage: `url(${img.url})`}}>
                                     {(settings.background.type === 'image' && settings.background.value === img.url) && <div className="absolute inset-0 bg-black/30 flex items-center justify-center"><CheckIcon className="w-6 h-6 text-white"/></div>}
                                </button>
                            ))}
                            <div className={`relative aspect-square rounded-lg border-2 flex items-center justify-center ${settings.background.type === 'color' ? 'border-[var(--accent)]' : 'border-[var(--border-color)]'}`} style={{ backgroundColor: settings.background.type === 'color' ? settings.background.value : 'transparent' }}>
                                <input type="color" value={settings.background.type === 'color' ? settings.background.value : '#ffffff'} onChange={(e) => handleBackgroundChange({ type: 'color', value: e.target.value })} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"/>
                                <div className="w-6 h-6 rounded-full" style={{backgroundColor: settings.background.type === 'color' ? settings.background.value : '#ccc' }} />
                            </div>
                         </div>
                     </FormRow>
                     {settings.background.type === 'image' && (
                        <FormRow label="Nivel de Desenfoque">
                            <div className="w-full sm:w-2/3 flex items-center gap-3">
                                <input
                                    type="range"
                                    min="0"
                                    max="32"
                                    step="1"
                                    value={settings.background.blur ?? 8}
                                    onChange={handleBlurChange}
                                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                                    style={{ accentColor: 'var(--accent)'}}
                                />
                                <span className="text-sm font-mono w-12 text-center text-[var(--text-secondary)]">{settings.background.blur ?? 8}px</span>
                                <button
                                    onClick={handleResetBlur}
                                    className="text-xs text-[var(--text-secondary)] hover:text-[var(--accent)]"
                                >
                                    Reset
                                </button>
                            </div>
                        </FormRow>
                     )}
                </section>


                 <section className="mt-6">
                    <h3 className="font-semibold mb-3 text-sm uppercase text-[var(--text-secondary)]">Voz</h3>
                     <FormRow label="Voz de Asclepio">
                        <select
                            value={settings.voice?.voiceURI || ''}
                            onChange={handleVoiceChange}
                            className="w-full sm:w-2/3 bg-transparent text-[var(--text-primary)] rounded-lg px-3 py-2 border border-[var(--border-color)] focus:outline-none focus:ring-2 focus:ring-[var(--accent)] focus:border-[var(--accent)] transition-colors duration-200"
                        >
                            {voices.map(v => (
                                <option key={v.voiceURI} value={v.voiceURI}>{v.name}</option>
                            ))}
                        </select>
                    </FormRow>
                </section>

                <section className="mt-6">
                     <h3 className="font-semibold mb-3 text-sm uppercase text-[var(--text-secondary)]">Personalización</h3>
                     <FormRow label="Tu Nombre">
                        <TextInput name="name" value={settings.userInfo.name} onChange={handleUserInfoChange} />
                     </FormRow>
                     <FormRow label="Tu Oficio">
                        <TextInput name="occupation" value={settings.userInfo.occupation} onChange={handleUserInfoChange} />
                     </FormRow>
                     <FormRow label="Tus Preferencias">
                        <TextArea name="preferences" value={settings.userInfo.preferences} onChange={handleUserInfoChange} />
                     </FormRow>
                </section>

                <section className="mt-6 pt-4 border-t border-[var(--border-color)]">
                    <h3 className="font-semibold mb-3 text-sm uppercase text-[var(--text-secondary)]">Ayuda</h3>
                     <FormRow label="Guía Interactiva">
                         <button 
                            onClick={onStartTutorial}
                            className="flex items-center gap-2 px-3 py-1.5 text-sm text-[var(--accent)] bg-[var(--accent-light)] rounded-lg hover:opacity-80 transition-opacity"
                         >
                            <InfoIcon className="w-4 h-4" />
                            <span>Iniciar Tutorial</span>
                         </button>
                     </FormRow>
                </section>

            </div>
        </div>
    );
};