import React from 'react';

interface LogoProps {
  isIdle: boolean;
}

const logoText = "A S C L E P I O";

export const Logo: React.FC<LogoProps> = ({ isIdle }) => {
  return (
    <div className={`app-logo ${isIdle ? 'logo-idle' : 'logo-active'}`}>
      {logoText.split('').map((char, index) => (
        <span
          key={index}
          style={{ animationDelay: isIdle ? `${index * 100}ms` : '0s' }}
        >
          {char === ' ' ? '\u00A0' : char}
        </span>
      ))}
    </div>
  );
};
