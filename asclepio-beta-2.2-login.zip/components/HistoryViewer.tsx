import React from 'react';
import { ConversationSession, BoardContent, BoardContentType, Theme } from '../types.ts';
import { CloseIcon } from './icons/CloseIcon.tsx';
import { InformationBoard } from './InformationBoard.tsx';

// A "Static" version of the InformationBoard that doesn't rely on external state like currentHighlightId.
const StaticBoardContent: React.FC<{ content: BoardContent, theme: Theme }> = ({ content, theme }) => {
    return (
        <div className="mt-3 scale-95 origin-top-left">
             <InformationBoard content={content} currentHighlightId={null} theme={theme} />
        </div>
    )
};


interface HistoryViewerProps {
  session: ConversationSession | null;
  onClose: () => void;
  theme: Theme;
}

export const HistoryViewer: React.FC<HistoryViewerProps> = ({ session, onClose, theme }) => {
  if (!session) return null;

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-md z-50 flex items-center justify-center p-4 animate-fade-in" onClick={onClose}>
      <div
        className="bg-[var(--control-bg)] backdrop-blur-xl w-full max-w-3xl h-[90vh] max-h-[800px] rounded-2xl shadow-2xl border border-[var(--border-color)] flex flex-col"
        onClick={e => e.stopPropagation()}
      >
        <header className="flex items-center justify-between p-4 border-b border-[var(--border-color)] flex-shrink-0">
          <div>
            <h2 className="text-lg font-bold truncate pr-4" title={session.title}>{session.title}</h2>
            <p className="text-sm text-[var(--text-secondary)]">{new Date(session.startTime).toLocaleString()}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-full text-[var(--text-secondary)] hover:bg-[var(--accent-light)] transition-colors flex-shrink-0">
            <CloseIcon className="w-5 h-5" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 custom-scrollbar">
          {session.turns.map((turn, index) => (
            <div key={index} className="flex flex-col gap-2 animate-fade-in" style={{animationDelay: `${index * 100}ms`}}>
              {/* User Input */}
              <div className="self-end w-full max-w-xl">
                <div className="bg-[var(--accent-light)] text-[var(--text-primary)] rounded-2xl rounded-br-md p-3">
                  <p className="font-semibold text-sm text-[var(--accent)] mb-1">Tú</p>
                  <p className="whitespace-pre-wrap">{turn.userInput}</p>
                </div>
              </div>

              {/* Asclepio Response */}
               <div className="self-start w-full max-w-xl">
                <div className="bg-[var(--control-bg)]/[0.5] text-[var(--text-primary)] rounded-2xl rounded-bl-md p-3">
                   <p className="font-semibold text-sm text-[var(--text-secondary)] mb-1">Asclepio</p>
                   <p className="whitespace-pre-wrap mb-2">
                     {turn.asclepioSpeech.map(s => s.text).join(' ')}
                   </p>
                   {turn.boardContent && (
                        <div className="border-t border-[var(--border-color)] pt-2">
                           <StaticBoardContent content={turn.boardContent} theme={theme} />
                        </div>
                   )}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};