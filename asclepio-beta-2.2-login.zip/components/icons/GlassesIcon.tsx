import React from 'react';
export const GlassesIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="6" cy="12" r="4" />
    <circle cx="18" cy="12" r="4" />
    <line x1="10" y1="12" x2="14" y2="12" />
  </svg>
);
