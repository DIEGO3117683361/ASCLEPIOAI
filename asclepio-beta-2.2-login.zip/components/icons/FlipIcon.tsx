import React from 'react';

export const FlipIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
    <svg 
        {...props} 
        xmlns="http://www.w3.org/2000/svg" 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
    >
        <path d="M16 4h4v4" />
        <path d="M14.96 9.04 20 4" />
        <path d="M8 20H4v-4" />
        <path d="M9.04 14.96 4 20" />
    </svg>
);
