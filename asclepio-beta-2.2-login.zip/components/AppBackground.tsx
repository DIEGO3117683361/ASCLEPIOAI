import React from 'react';
import { BackgroundSetting, Theme } from '../types.ts';

interface AppBackgroundProps {
  setting: BackgroundSetting;
  theme: Theme;
}

export const AppBackground: React.FC<AppBackgroundProps> = ({ setting, theme }) => {
    const isImage = setting.type === 'image';
    const isColor = setting.type === 'color';

    const rootStyle: React.CSSProperties = {
        backgroundColor: isColor ? setting.value : 'var(--background)'
    };

    const imageStyle: React.CSSProperties = {
        backgroundImage: isImage ? `url(${setting.value})` : 'none',
        opacity: isImage ? 1 : 0,
        filter: isImage ? `blur(${setting.blur ?? 8}px)` : 'none',
        transform: isImage ? 'scale(1.1)' : 'scale(1)',
    };
    
    const overlayStyle: React.CSSProperties = {
        opacity: isImage ? 1 : 0,
    };

    return (
        <div
            className="fixed inset-0 -z-10 transition-colors duration-300"
            style={rootStyle}
        >
            <div className="app-bg-image" style={imageStyle} />
            <div className="app-bg-overlay transition-opacity duration-500" style={overlayStyle} />
        </div>
    );
};