import { useState, useRef, useCallback, useEffect } from 'react';
import { InteractionStatus, BoardContent, BoardContentType, Settings, SpeechSegment, InteractionTurn } from '../types.ts';
import { createAsclepioChat, generateImage, ai, getSystemInstruction, getSearchSystemInstruction } from '../services/geminiService.ts';
import type { Chat } from '@google/genai';

interface UseVoiceInteractionProps {
    settings: Settings;
    onSessionEnd: (turns: InteractionTurn[]) => void;
}

// Speech API interfaces
interface SpeechRecognitionAlternative { readonly transcript: string; readonly confidence: number; }
interface SpeechRecognitionResult { readonly isFinal: boolean; readonly length: number; item(index: number): SpeechRecognitionAlternative; [index: number]: SpeechRecognitionAlternative; }
interface SpeechRecognitionResultList { readonly length: number; item(index: number): SpeechRecognitionResult; [index: number]: SpeechRecognitionResult; }
interface SpeechRecognitionErrorEvent extends Event { readonly error: string; readonly message: string; }
interface SpeechRecognitionEvent extends Event { readonly resultIndex: number; readonly results: SpeechRecognitionResultList; }
interface SpeechRecognition extends EventTarget { lang: string; continuous: boolean; interimResults: boolean; start(): void; abort(): void; stop(): void; onresult: (event: SpeechRecognitionEvent) => void; onend: () => void; onerror: (event: SpeechRecognitionErrorEvent) => void; }
interface SpeechRecognitionStatic { new(): SpeechRecognition; }
declare global { interface Window { SpeechRecognition: SpeechRecognitionStatic; webkitSpeechRecognition: SpeechRecognitionStatic; } }
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

const getFriendlyErrorMessage = (error: any): string => {
    const defaultMessage = "Lo siento, ha ocurrido un problema de comunicación. Por favor, inténtalo de nuevo.";
    if (error instanceof Error) {
        const message = error.message.toLowerCase();
        if (message.includes('resource_exhausted') || message.includes('429')) {
            return "He recibido muchas solicitudes en poco tiempo. Por favor, dame un momento para descansar y vuelve a intentarlo en unos segundos.";
        }
        if (message.includes('api key not valid')) {
            return "Parece que hay un problema con la configuración. No puedo conectarme en este momento.";
        }
        // Return a cleaner version of other common errors.
        if (message.includes('no se generó ninguna imagen')) {
            return "Lo siento, no pude generar la imagen solicitada. Es posible que haya sido bloqueada por filtros de seguridad.";
        }
        return error.message;
    }
    // Attempt to parse if the error is a JSON string
    try {
        const parsedError = JSON.parse(error);
        if (parsedError?.error?.message) {
            return getFriendlyErrorMessage(new Error(parsedError.error.message));
        }
    } catch(e) {
        // Not a JSON string, fall through
    }

    return typeof error === 'string' ? error : defaultMessage;
};


export function useVoiceInteraction({ settings, onSessionEnd }: UseVoiceInteractionProps) {
  const [status, setStatus] = useState<InteractionStatus>(InteractionStatus.IDLE);
  const [error, setError] = useState<string | null>(null);
  const [boardContent, setBoardContent] = useState<BoardContent | null>(null);
  const [currentSpokenText, setCurrentSpokenText] = useState<string | null>(null);
  const [currentHighlightId, setCurrentHighlightId] = useState<string | null>(null);
  const [isPresentationMode, setIsPresentationMode] = useState(false);
  const [isSearchMode, setIsSearchMode] = useState(false);

  const chatRef = useRef<Chat | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const wakeLockRef = useRef<WakeLockSentinel | null>(null);
  const isInterruptedRef = useRef<boolean>(false);
  const speechQueueRef = useRef<SpeechSegment[]>([]);
  const inactivityTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const turnsRef = useRef<InteractionTurn[]>([]);


  // Ref to hold the current status, to be used in callbacks to avoid stale closures.
  const statusRef = useRef(status);
  useEffect(() => {
    statusRef.current = status;
  }, [status]);
  
  const handleError = useCallback((errorMessage: string) => {
    console.error(errorMessage);
    setError(errorMessage);
    setStatus(InteractionStatus.ERROR);
    setCurrentSpokenText(null);
    setCurrentHighlightId(null);
  }, []);
  
  const endSession = useCallback(() => {
    if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    
    // Save session if there are turns.
    if (turnsRef.current.length > 0) {
      onSessionEnd(turnsRef.current);
      turnsRef.current = [];
    }

    isInterruptedRef.current = true;
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (recognitionRef.current) recognitionRef.current.abort();

    if (statusRef.current !== InteractionStatus.IDLE && statusRef.current !== InteractionStatus.SLEEPING) {
        setStatus(InteractionStatus.SLEEPING);
    }
  }, [onSessionEnd]);
  
  const listen = useCallback(() => {
    if (recognitionRef.current) {
        try {
            recognitionRef.current.start();
        } catch (e) {
            // It might fail if it's already started, which is fine in our case.
            if (!(e instanceof DOMException && e.name === 'InvalidStateError')) {
                console.warn("Speech recognition couldn't start:", e);
            }
        }
    }
  }, []);

  // Effect to automatically start listening based on the current status.
  useEffect(() => {
    if (status === InteractionStatus.LISTENING || status === InteractionStatus.AWAITING_CONTINUATION) {
      listen();
    }
    
    // Inactivity timer
    if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    if (status === InteractionStatus.AWAITING_CONTINUATION) {
        inactivityTimerRef.current = setTimeout(() => {
            console.log("Inactivity detected, ending session.");
            endSession();
        }, 60000); // 60 seconds
    }
    
  }, [status, listen, endSession]);
  
  const speakNextInQueue = useCallback(() => {
      if (isInterruptedRef.current) {
          speechQueueRef.current = [];
          isInterruptedRef.current = false;
          if (statusRef.current !== InteractionStatus.SLEEPING) {
             setStatus(InteractionStatus.LISTENING);
          }
          return;
      }
      
      if (speechQueueRef.current.length === 0) {
          setCurrentSpokenText(null);
          setCurrentHighlightId(null);
          setStatus(InteractionStatus.AWAITING_CONTINUATION);
          return;
      }
      
      const segment = speechQueueRef.current.shift();
      if (!segment) {
          setStatus(InteractionStatus.AWAITING_CONTINUATION);
          return;
      }

      if (!window.speechSynthesis) {
        console.warn("Speech Synthesis API not supported. Cannot speak.");
        handleError("Tu navegador no soporta la síntesis de voz.");
        return;
      }

      const { text, highlightId } = segment;
      
      const utterance = new SpeechSynthesisUtterance(text);
      const allVoices = window.speechSynthesis.getVoices();
      const selectedVoice = allVoices.find(v => v.voiceURI === settings.voice?.voiceURI);

      utterance.voice = selectedVoice || null;
      utterance.lang = selectedVoice?.lang || 'es-ES';
      utterance.rate = 1.1;
      utterance.pitch = 0.9;

      utterance.onstart = () => {
          setStatus(InteractionStatus.SPEAKING);
          setCurrentSpokenText(text);
          setCurrentHighlightId(highlightId || null);
      };

      utterance.onend = () => {
          speakNextInQueue();
      };
      
      utterance.onerror = (event) => {
          if (event.error === 'interrupted' || event.error === 'canceled') {
              console.log(`Speech synthesis was intentionally interrupted: ${event.error}`);
              return;
          }
          
          handleError(`Speech synthesis error: ${event.error}`);
          speakNextInQueue();
      };
      
      window.speechSynthesis.speak(utterance);
  }, [handleError, settings.voice]);

  const speak = useCallback((segments: SpeechSegment[]) => {
      isInterruptedRef.current = false;

      if (recognitionRef.current) {
          recognitionRef.current.abort();
      }
      speechQueueRef.current = [...segments];
      speakNextInQueue();
  }, [speakNextInQueue]);

  const processAndRespond = useCallback(async (text: string) => {
    setStatus(InteractionStatus.THINKING);
    setBoardContent(null);
    setCurrentHighlightId(null);

    let finalPrompt = text;

    try {
      let finalSpeech: SpeechSegment[];
      let finalBoardContent: BoardContent | null = null;
      let isConversationEnding = false;

      if (isSearchMode) {
        setIsSearchMode(false); // Reset after one use.

        // 1. Classify intent to determine if it's an image or web search.
        const intentPrompt = `Clasifica la siguiente consulta del usuario. Responde únicamente con la palabra "IMAGE" si la consulta parece ser una solicitud de una imagen, foto, ilustración, dibujo o algo visual. De lo contrario, responde únicamente con la palabra "WEB".\n\nConsulta: "${finalPrompt}"`;
        
        const intentResponse = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: intentPrompt,
        });
        const intent = intentResponse.text.trim().toUpperCase();

        if (intent === 'IMAGE') {
            // It's an image request. Generate an image.
            
            // 2a. Create a descriptive English prompt for the image model.
            const imagePromptInstruction = `Basado en la siguiente consulta del usuario, crea un prompt conciso, detallado y descriptivo en inglés para un modelo de generación de imágenes de IA. El prompt debe enfocarse en los elementos visuales. Consulta del usuario: "${finalPrompt}"`;
            const imagePromptResponse = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: imagePromptInstruction,
            });
            const imagePrompt = imagePromptResponse.text.trim();

            // 3a. Generate the image using the new prompt.
            const base64Image = await generateImage(imagePrompt);
            finalBoardContent = { type: BoardContentType.IMAGE, data: { src: `data:image/jpeg;base64,${base64Image}`, prompt: imagePrompt } };
            finalSpeech = [{ text: `Claro, he generado una imagen basada en tu petición: "${finalPrompt}".` }];

        } else { // 'WEB' or fallback
            // It's a web search request. Use Google Search tool.
            const response = await ai.models.generateContent({
                model: "gemini-2.5-flash",
                contents: finalPrompt,
                config: {
                    systemInstruction: getSearchSystemInstruction(settings.userInfo),
                    tools: [{googleSearch: {}}],
                },
            });
            
            const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
            const firstWebResult = groundingChunks.find(c => c.web?.uri && c.web.uri.startsWith('http'));

            if (firstWebResult && firstWebResult.web) {
                // Display the found web page.
                finalBoardContent = { type: BoardContentType.WEB_PAGE, data: { url: firstWebResult.web.uri } };
                const summary = response.text ? response.text : `Encontré esta página sobre tu consulta.`;
                finalSpeech = [{ text: summary }, { text: `La estoy mostrando ahora en el tablero.` }];
            } else {
                // If no web page is found, show the text summary.
                finalBoardContent = { type: BoardContentType.TEXT, data: { htmlContent: `<p>${response.text}</p>` } };
                finalSpeech = [{ text: response.text || "No pude encontrar una página web para mostrar, pero aquí tienes un resumen." }];
            }
        }

      } else {
        if (!chatRef.current) {
            handleError("Chat no inicializado. Por favor, reinicia la sesión.");
            return;
        }

        if (isPresentationMode) {
            finalPrompt = `En formato de presentación, explícame lo siguiente: ${text}`;
            setIsPresentationMode(false); // Reset after use
        }
        
        const response = await chatRef.current.sendMessage({ message: finalPrompt });
        const responseText = response.text;
        
        let parsedResponse;
        try {
             parsedResponse = JSON.parse(responseText);
        } catch(parseError) {
             console.error("Error al parsear JSON:", parseError, "Respuesta recibida:", responseText);
             throw new Error("La respuesta del servidor no es un JSON válido.");
        }

        const { speech: speechSegments, boardContent: newBoardContent, isConversationEnding: convEnd } = parsedResponse;
        isConversationEnding = convEnd;
        
        if (Array.isArray(speechSegments) && speechSegments.length > 0) {
            finalSpeech = speechSegments;
        } else {
            finalSpeech = [{ text: "No he podido generar una respuesta." }];
        }
        
        if (newBoardContent && newBoardContent.data && typeof newBoardContent.data === 'string') {
            try {
                const sanitizedDataString = newBoardContent.data.replace(/[\x00-\x1F\x7F-\x9F]/g, "");
                const boardData = JSON.parse(sanitizedDataString);

                switch(newBoardContent.type) {
                    case 'image_prompt':
                        const base64Image = await generateImage(boardData.prompt);
                        finalBoardContent = { type: BoardContentType.IMAGE, data: { src: `data:image/jpeg;base64,${base64Image}`, prompt: boardData.prompt } };
                        break;
                    case 'text':
                        finalBoardContent = { type: BoardContentType.TEXT, data: boardData.htmlContent };
                        break;
                    case 'guitar_fretboard':
                        finalBoardContent = { type: BoardContentType.GUITAR_FRETBOARD, data: boardData };
                        break;
                    case 'youtube_video':
                        finalBoardContent = { type: BoardContentType.YOUTUBE_VIDEO, data: boardData };
                        break;
                    case 'web_article':
                        finalBoardContent = { type: BoardContentType.WEB_ARTICLE, data: boardData };
                        break;
                    case 'code':
                        finalBoardContent = { type: BoardContentType.CODE, data: boardData };
                        break;
                    case 'flashcards':
                        finalBoardContent = { type: BoardContentType.FLASHCARDS, data: boardData };
                        break;
                    case 'quiz':
                        finalBoardContent = { type: BoardContentType.QUIZ, data: boardData };
                        break;
                    case 'presentation':
                        finalBoardContent = { type: BoardContentType.PRESENTATION, data: boardData };
                        break;
                    default:
                         console.warn(`Tipo de tablero desconocido: ${newBoardContent.type}`);
                }
            } catch (contentError: any) {
                console.error("Error procesando contenido del tablero:", contentError);
                const friendlyError = getFriendlyErrorMessage(contentError);
                finalSpeech = [{ text: `Lo siento, he encontrado un problema al preparar la información visual. ${friendlyError}` }];
                finalBoardContent = null;
            }
        }
      }
        
      setBoardContent(finalBoardContent);

      const newTurn: InteractionTurn = {
          userInput: finalPrompt,
          asclepioSpeech: finalSpeech,
          boardContent: finalBoardContent,
      };
      turnsRef.current.push(newTurn);

      speak(finalSpeech);

      if (isConversationEnding) {
          const speechDuration = finalSpeech.reduce((acc: number, s: SpeechSegment) => acc + s.text.length, 0) * 60; // Estimate duration
          setTimeout(endSession, Math.max(speechDuration, 2000));
      }

    } catch (e: any) {
        console.error("Error principal en Gemini:", e);
        const friendlyError = getFriendlyErrorMessage(e);
        handleError(friendlyError);
        speak([{ text: friendlyError }]);
    }
  }, [handleError, speak, endSession, isPresentationMode, isSearchMode, settings.userInfo]);


  const initializeSession = useCallback(async (isReset: boolean = false) => {
    if (!SpeechRecognition) {
      handleError("Tu navegador no soporta la API de reconocimiento de voz. Intenta con Chrome.");
      return false;
    }

    if (!window.speechSynthesis) {
        handleError("Tu navegador no soporta la API de síntesis de voz. No podré hablar.");
    }
    
    if (!isReset) {
      setStatus(InteractionStatus.INITIALIZING);
    }
    setError(null);
    setBoardContent(null);

    try {
      await navigator.mediaDevices.getUserMedia({ audio: true });
      
      if ('wakeLock' in navigator) {
          try { wakeLockRef.current = await navigator.wakeLock.request('screen'); } 
          catch (err: any) { console.warn(`Wake Lock no se pudo activar: ${err.name}, ${err.message}`); }
      }

      chatRef.current = createAsclepioChat(settings.userInfo);

      const recognition = new SpeechRecognition();
      recognition.lang = 'es-ES';
      recognition.continuous = false;
      recognition.interimResults = false;

      recognition.onresult = (event: SpeechRecognitionEvent) => {
        const results = event.results;
        if (results && results.length > 0) {
            const lastResult = results[results.length - 1];
            if (lastResult && lastResult.length > 0) {
                const transcript = lastResult[0].transcript.trim();
                if (transcript) {
                    processAndRespond(transcript);
                }
            }
        }
      };
      
      recognition.onend = () => {
        if (statusRef.current === InteractionStatus.LISTENING || statusRef.current === InteractionStatus.AWAITING_CONTINUATION) {
           listen();
        }
      };
      
      recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
          if (event.error === 'no-speech' || event.error === 'aborted') {
            // 'no-speech' happens if user is quiet, 'aborted' happens on interrupt. Both are normal.
            return;
          }

          console.error(`Speech recognition error: ${event.error}`, event);
          
          let friendlyMessage = "Ha ocurrido un error con el reconocimiento de voz.";
          switch(event.error) {
              case 'network':
                  friendlyMessage = "Se perdió la conexión con el servicio de voz. Por favor, revisa tu conexión a internet e inténtalo de nuevo.";
                  break;
              case 'audio-capture':
                  friendlyMessage = "No puedo acceder al micrófono. Verifica que no esté siendo usado por otra aplicación y que los permisos estén correctos.";
                  break;
              case 'not-allowed':
                  friendlyMessage = "Permiso para el micrófono denegado. No puedo escucharte sin acceso al micrófono.";
                  break;
              case 'service-not-allowed':
                  friendlyMessage = "El servicio de reconocimiento de voz está desactivado. Por favor, revisa la configuración de tu navegador o sistema operativo.";
                  break;
              default:
                  friendlyMessage = `Ocurrió un error inesperado al intentar escucharte (${event.error}).`;
          }
          
          handleError(friendlyMessage);
      };

      recognitionRef.current = recognition;
      return true;
    } catch (err) {
      handleError("Se necesita permiso para el micrófono para comenzar.");
      return false;
    }
  }, [handleError, processAndRespond, settings.userInfo, listen]);
  
  const startSession = useCallback(async () => {
    turnsRef.current = []; // Clear history for new session
    const success = await initializeSession(false);
    if (success) {
      setStatus(InteractionStatus.AWAKENING);
    }
  }, [initializeSession]);
  
  const handleAnimationEnd = useCallback(() => {
     if (statusRef.current === InteractionStatus.AWAKENING) {
         const initialGreeting = `Hola ${settings.userInfo.name || ''}, soy Asclepio. ¿En qué puedo ayudarte hoy?`;
         speak([{ text: initialGreeting }]);
     } else if (statusRef.current === InteractionStatus.SLEEPING) {
         setStatus(InteractionStatus.IDLE);
         setBoardContent(null);
         setCurrentHighlightId(null);
         setCurrentSpokenText(null);
         setError(null);
         chatRef.current = null;
         if (wakeLockRef.current) wakeLockRef.current.release().catch(() => {});
         wakeLockRef.current = null;
     }
  }, [settings.userInfo.name, speak]);
  
  const resetSession = useCallback(async () => {
      endSession();
      setIsPresentationMode(false);
      setIsSearchMode(false);
  }, [endSession]);

  const interrupt = useCallback(() => {
    isInterruptedRef.current = true;
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    if (recognitionRef.current) recognitionRef.current.abort();
    speechQueueRef.current = [];
    setCurrentSpokenText(null);
    setCurrentHighlightId(null);
    setStatus(InteractionStatus.LISTENING);
  }, []);

  const submitTextMessage = useCallback((text: string) => {
    if (text.trim()) {
        isInterruptedRef.current = true;
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        speechQueueRef.current = [];
        if (recognitionRef.current) recognitionRef.current.abort();
        processAndRespond(text.trim());
    }
  }, [processAndRespond]);

  const handleContinue = useCallback(() => {
    if (recognitionRef.current) recognitionRef.current.abort();
    processAndRespond("OK, continua");
  }, [processAndRespond]);

  const togglePresentationMode = useCallback(() => {
    setIsPresentationMode(prev => !prev);
  }, []);

  const toggleSearchMode = useCallback(() => {
    setIsSearchMode(prev => !prev);
  }, []);

  useEffect(() => {
    return () => {
        if (recognitionRef.current) recognitionRef.current.abort();
        if (window.speechSynthesis) window.speechSynthesis.cancel();
        if (wakeLockRef.current) wakeLockRef.current.release().catch(() => {});
        if (inactivityTimerRef.current) clearTimeout(inactivityTimerRef.current);
    }
  }, []);

  return { status, error, startSession, resetSession, boardContent, interrupt, submitTextMessage, handleContinue, currentSpokenText, currentHighlightId, handleAnimationEnd, isPresentationMode, togglePresentationMode, isSearchMode, toggleSearchMode };
}