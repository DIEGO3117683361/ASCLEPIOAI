import { useState, useEffect, useCallback } from 'react';
import { Theme, UserInfo, Voice, Settings, BackgroundSetting, FaceCustomization } from '../types.ts';

const getStoredValue = <T,>(key: string, defaultValue: T): T => {
    try {
        const item = window.localStorage.getItem(key);
        return item ? JSON.parse(item) : defaultValue;
    } catch (error) {
        console.error(`Error reading localStorage key “${key}”:`, error);
        return defaultValue;
    }
};

const useStoredState = <T,>(key: string, defaultValue: T): [T, (value: T | ((val: T) => T)) => void] => {
    const [value, setValue] = useState<T>(() => getStoredValue(key, defaultValue));

    useEffect(() => {
        try {
            window.localStorage.setItem(key, JSON.stringify(value));
        } catch (error) {
            console.error(`Error setting localStorage key “${key}”:`, error);
        }
    }, [key, value]);

    return [value, setValue];
};

export function useSettings() {
    const [theme, setTheme] = useStoredState<Theme>('settings:theme', 'light');
    const [userInfo, setUserInfo] = useStoredState<UserInfo>('settings:userInfo', {
        name: '',
        occupation: '',
        preferences: '',
    });
    const [selectedVoiceURI, setSelectedVoiceURI] = useStoredState<string | null>('settings:voiceURI', null);
    const [showSubtitles, setShowSubtitles] = useStoredState<boolean>('settings:showSubtitles', false);
    const [background, setBackground] = useStoredState<BackgroundSetting>('settings:background', { type: 'default', value: '' });
    const [face, setFace] = useStoredState<FaceCustomization>('settings:face', {
        accessory: 'none',
        color: '#007aff', // Default for light theme
        strokeWidth: 1.5,
    });
    const [voices, setVoices] = useState<Voice[]>([]);

    useEffect(() => {
        // Update face color based on theme if it's still a default color
        const lightDefault = '#007aff';
        const darkDefault = '#0a84ff';
        if (theme === 'dark' && face.color === lightDefault) {
            setFace(f => ({ ...f, color: darkDefault }));
        }
        if (theme === 'light' && face.color === darkDefault) {
            setFace(f => ({ ...f, color: lightDefault }));
        }
    }, [theme, face.color, setFace]);

    const populateVoiceList = useCallback(() => {
        if (!window.speechSynthesis) {
            console.warn("Speech Synthesis API is not supported in this browser.");
            return;
        }
        const availableVoices = (window.speechSynthesis.getVoices() || [])
            .filter(v => v.lang.startsWith('es') || v.lang.startsWith('en'))
            .map(v => ({
                name: `${v.name} (${v.lang})`,
                lang: v.lang,
                voiceURI: v.voiceURI
            }));
        setVoices(availableVoices);
        
        if (!selectedVoiceURI && availableVoices.length > 0) {
            const spanishVoice = availableVoices.find(v => v.lang === 'es-ES') || availableVoices.find(v => v.lang === 'es-US') || availableVoices[0];
            setSelectedVoiceURI(spanishVoice.voiceURI);
        }
    }, [selectedVoiceURI, setSelectedVoiceURI]);


    useEffect(() => {
        populateVoiceList();
        if (window.speechSynthesis && window.speechSynthesis.onvoiceschanged !== undefined) {
            window.speechSynthesis.onvoiceschanged = populateVoiceList;
        }
    }, [populateVoiceList]);

    const settings: Settings = {
        theme,
        userInfo,
        voice: voices.find(v => v.voiceURI === selectedVoiceURI) || null,
        showSubtitles,
        background,
        face,
    };

    const setSettings = (newSettings: Partial<Settings>) => {
        if (newSettings.theme !== undefined) setTheme(newSettings.theme);
        if (newSettings.userInfo !== undefined) setUserInfo(newSettings.userInfo);
        if (newSettings.voice) setSelectedVoiceURI(newSettings.voice.voiceURI);
        if (newSettings.showSubtitles !== undefined) setShowSubtitles(newSettings.showSubtitles);
        if (newSettings.background !== undefined) setBackground(newSettings.background);
        if (newSettings.face !== undefined) setFace(newSettings.face);
    };
    
    return { settings, setSettings, voices };
}