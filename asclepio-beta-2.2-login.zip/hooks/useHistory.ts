
import { useState, useEffect, useCallback } from 'react';
import { ConversationSession } from '../types.ts';

const STORAGE_KEY = 'asclepio:chatHistory';

export function useHistory() {
    const [history, setHistory] = useState<ConversationSession[]>([]);

    useEffect(() => {
        try {
            const storedHistory = window.localStorage.getItem(STORAGE_KEY);
            if (storedHistory) {
                // Sort by start time descending to show newest first
                const parsed = JSON.parse(storedHistory);
                setHistory(parsed.sort((a: ConversationSession, b: ConversationSession) => b.startTime - a.startTime));
            }
        } catch (error) {
            console.error("Failed to load history from localStorage:", error);
        }
    }, []);

    const updateLocalStorage = (newHistory: ConversationSession[]) => {
        try {
            window.localStorage.setItem(STORAGE_KEY, JSON.stringify(newHistory));
        } catch (error) {
            console.error("Failed to save history to localStorage:", error);
        }
    };

    const addSession = useCallback((session: ConversationSession) => {
        setHistory(prevHistory => {
            const newHistory = [session, ...prevHistory];
            updateLocalStorage(newHistory);
            return newHistory;
        });
    }, []);

    const clearHistory = useCallback(() => {
        if (window.confirm("¿Estás seguro de que quieres borrar todo el historial de conversaciones? Esta acción no se puede deshacer.")) {
            setHistory([]);
            updateLocalStorage([]);
        }
    }, []);

    return { history, addSession, clearHistory };
}