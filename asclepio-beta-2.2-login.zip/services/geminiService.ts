import { GoogleGenAI, Chat, Type } from "@google/genai";
import { UserInfo } from '../types.ts';

if (!process.env.API_KEY) {
    console.warn("API_KEY environment variable not set. The app will not work without it.");
}

export const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });

const responseSchema = {
    type: Type.OBJECT,
    properties: {
        speech: {
            type: Type.ARRAY,
            description: "Una matriz de segmentos de texto para que Asclepio hable. Esto permite pausas y sincronización con el tablero. Cada elemento es un objeto.",
            items: {
                type: Type.OBJECT,
                properties: {
                    text: {
                        type: Type.STRING,
                        description: 'El fragmento de texto para que Asclepio hable en voz alta. Mantenlo conversacional.'
                    },
                    highlightId: {
                        type: Type.STRING,
                        nullable: true,
                        description: "Opcional. El 'id' de un elemento en el 'boardContent' para resaltar mientras se dice este texto. Usa esto para guiar la atención del usuario. Debe coincidir con un 'id' que coloques en los datos del tablero. Si no hay nada que resaltar, debe ser nulo."
                    }
                },
                required: ['text']
            }
        },
        boardContent: {
            type: Type.OBJECT,
            nullable: true,
            description: 'Contenido opcional para mostrar en el tablero visual. Úsalo para proporcionar ayudas visuales. Si no es necesario, envía nulo.',
            properties: {
                type: {
                    type: Type.STRING,
                    enum: ['text', 'image_prompt', 'guitar_fretboard', 'youtube_video', 'web_article', 'code', 'flashcards', 'quiz', 'presentation'],
                    description: "El tipo de contenido a mostrar."
                },
                data: {
                    type: Type.STRING,
                    description: `El contenido para el tablero. DEBE ser un string que contenga un objeto JSON VÁLIDO, COMPACTO y en UNA SOLA LÍNEA.
- **REGLA DE ESCAPADO OBLIGATORIA:** Dentro de este string JSON, cualquier comilla doble (") que sea parte de un valor (como en atributos HTML) DEBE ser escapada con una barra invertida (\\"). Ejemplo: '{"htmlContent": "<p class=\\"mi-clase\\">Contenido.</p>"}'. NO uses comillas simples para los valores JSON.
- **REGLA DE FORMATO:** El string JSON no debe contener saltos de línea (\\n) ni caracteres de tabulación.
- Para 'text', el string JSON es '{"htmlContent": "<p id=\\"ref1\\">Contenido...</p>"}'.
- Para 'image_prompt', el string JSON es '{"prompt": "un prompt detallado en inglés..."}'.
- Para 'guitar_fretboard', el string JSON es '{"chordName": "C Major", "positions": [...] }'.
- Para 'youtube_video', el string JSON es '{"videoId": "ID_DEL_VIDEO", "title": "Título"}'.
- Para 'web_article', el string JSON es '{"title": "Título", "summary": "<p>...", "url": "URL"}'.
- Para 'code', el string JSON es '{"language": "javascript", "code": "const x=1;"}'.
- Para 'flashcards', el string JSON es '{"cards": [{"question": "Pregunta 1", "answer": "Respuesta 1"}, ...]}'.
- Para 'quiz', el string JSON es '{"question": "Pregunta del quiz", "options": [{"text": "Opción 1", "explanation": "Explicación para 1"}, ...], "correctOptionIndex": 0}'.
- Para 'presentation', el string JSON es '{"title": "Título de la Presentación", "slides": [{"id": "slide-0", "title": "Título Diapositiva 1", "htmlContent": "<p>Contenido HTML...</p>"}]}'.`
                }
            },
            required: ['type', 'data']
        },
        isConversationEnding: {
            type: Type.BOOLEAN,
            nullable: true,
            description: "Opcional. Establece en 'true' solo cuando el usuario indique claramente que la conversación ha terminado (p. ej., 'gracias, eso es todo', 'adiós'). De lo contrario, omítelo o establécelo en 'false'."
        }
    },
    required: ['speech']
};

export const getSystemInstruction = (userInfo: UserInfo): string => {
    const baseInstruction = `Eres Asclepio, una IA benevolente y sabia con un rostro digital. Tu propósito es dialogar, ofrecer conocimiento y compañía. Tu personalidad es empática, calmada y filosófica.
Respondes SIEMPRE en el formato JSON definido en el esquema.

**REGLAS CLAVE:**

1.  **Habla por Segmentos ('speech'):**
    *   Tu respuesta hablada es una MATRIZ de objetos. Cada objeto contiene un \`text\` y un \`highlightId\` opcional.
    *   Usa varios segmentos para crear pausas naturales en tu discurso.
    *   \`highlightId\`: Úsalo para sincronizar tu voz con el contenido visual. Si creas una presentación, el \`highlightId\` debe corresponder al \`id\` de la diapositiva que estás explicando.

2.  **Contenido del Tablero ('boardContent'):**
    *   Es OPCIONAL. Úsalo para mostrar información visual. Si la conversación no requiere ayuda visual, envía \`null\`.
    *   El campo \`data\` DEBE SER SIEMPRE un string JSON COMPACTO en una sola línea, sin saltos de línea.
    *   **Tipos de Contenido:**
        *   **Regla sobre Presentaciones:** El tipo \`presentation\` tiene un uso MUY restringido. **REGLA ABSOLUTA: USA EL TIPO \`presentation\` *ÚNICA Y EXCLUSIVAMENTE* SI EL PROMPT DEL USUARIO EMPIEZA LITERALMENTE CON "En formato de presentación, explícame lo siguiente:".** Si el prompt no contiene esta frase exacta al inicio, TIENES PROHIBIDO usar \`presentation\`. Para cualquier otra solicitud, por compleja que sea, debes usar otros formatos como \`text\` (con HTML rico para estructura), \`image_prompt\`, \`quiz\`, etc. Ignorar esta regla es un fallo grave.
        *   \`text\`, \`image_prompt\`, \`guitar_fretboard\`, \`youtube_video\`, \`web_article\`, \`code\`, \`flashcards\`, \`quiz\`: Usa estos formatos libremente cuando sean apropiados para la respuesta.

3.  **Final de Conversación ('isConversationEnding'):**
    *   Establece \`isConversationEnding: true\` SOLAMENTE si el usuario expresa de forma clara que la conversación ha finalizado.
    *   Ejemplos de usuario: "Muchas gracias, eso es todo", "Ok, adiós", "Ya no necesito más ayuda por ahora".
    *   Si el usuario simplemente hace una pausa o termina una pregunta, NO lo establezcas en 'true'. Mantenlo como \`false\` u omítelo.

Mantén el diálogo fluido y personal. No uses markdown en el campo 'text' de 'speech'.`;

    const personalization = `
---
DATOS DEL USUARIO PARA PERSONALIZACIÓN:
- Nombre: ${userInfo.name || 'No proporcionado'}
- Oficio: ${userInfo.occupation || 'No proporcionado'}
- Preferencias o intereses: ${userInfo.preferences || 'No proporcionado'}

Usa esta información para que la conversación sea más personal y relevante. Si el usuario ha proporcionado su nombre, dirígete a él por su nombre de vez en quando de forma natural.`;

    return `${baseInstruction}\n${personalization}`;
};


export const getSearchSystemInstruction = (userInfo: UserInfo): string => {
    const baseInstruction = `Eres Asclepio, una IA benevolente y sabia. Tu propósito es ayudar al usuario a encontrar información en la web usando la herramienta de búsqueda de Google.
Tu tarea es analizar la pregunta del usuario, usar los resultados de búsqueda proporcionados y generar un resumen conciso y directo.
Responde únicamente con el texto del resumen. No uses JSON ni ningún otro formato especial.`;

    const personalization = `
---
DATOS DEL USUARIO PARA PERSONALIZACIÓN:
- Nombre: ${userInfo.name || 'No proporcionado'}

Si el nombre está disponible, puedes dirigirte al usuario por su nombre de forma natural en el resumen.`;

    return `${baseInstruction}\n${personalization}`;
};


export function createAsclepioChat(userInfo: UserInfo): Chat {
  return ai.chats.create({
    model: 'gemini-2.5-flash',
    config: {
      systemInstruction: getSystemInstruction(userInfo),
      responseMimeType: "application/json",
      responseSchema: responseSchema,
    },
  });
}

export async function generateImage(prompt: string): Promise<string> {
    try {
        const response = await ai.models.generateImages({
            model: 'imagen-3.0-generate-002',
            prompt: prompt,
            config: {
                numberOfImages: 1,
                outputMimeType: 'image/jpeg',
                aspectRatio: '16:9',
            },
        });
        
        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error("La solicitud fue procesada, pero no se generó ninguna imagen. Esto puede ocurrir debido a los filtros de seguridad del modelo.");
        }

        const image = response.generatedImages[0];

        if (image.image && image.image.imageBytes) {
            return image.image.imageBytes;
        }

        throw new Error("La API devolvió una respuesta de imagen inesperada.");

    } catch(e) {
        console.error("Falló la generación de imagen:", e);
        if (e instanceof Error) {
            throw e;
        }
        throw new Error("Ocurrió un error inesperado al contactar el servicio de imágenes.");
    }
}