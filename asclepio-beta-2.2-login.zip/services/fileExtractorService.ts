import * as pdfjsLib from 'pdfjs-dist';
import mammoth from 'mammoth';
import { createWorker } from 'tesseract.js';

// Set up the PDF.js worker.
// This is crucial for it to work in a browser environment.
// By importing as a namespace, we can safely access GlobalWorkerOptions.
if (typeof window !== 'undefined') {
    // The worker is sourced from the same esm.sh bundle.
    pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://esm.sh/pdfjs-dist@4.4.170/build/pdf.worker.mjs';
}

async function extractPdfText(file: File): Promise<string> {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    const numPages = pdf.numPages;
    let fullText = '';

    for (let i = 1; i <= numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        fullText += textContent.items.map(item => ('str' in item ? item.str : '')).join(' ') + '\n\n';
    }

    return fullText;
}

async function extractDocxText(file: File): Promise<string> {
    const arrayBuffer = await file.arrayBuffer();
    const result = await mammoth.extractRawText({ arrayBuffer });
    return result.value;
}

async function extractImageText(file: File): Promise<string> {
    const worker = await createWorker('spa'); // Using Spanish language model
    const ret = await worker.recognize(file);
    await worker.terminate();
    return ret.data.text;
}

export async function extractTextFromFile(file: File): Promise<string> {
    const extension = file.name.split('.').pop()?.toLowerCase();
    const mimeType = file.type;

    if (extension === 'pdf' || mimeType === 'application/pdf') {
        return extractPdfText(file);
    }

    if (extension === 'docx' || mimeType === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        return extractDocxText(file);
    }
    
    if (['png', 'jpg', 'jpeg', 'bmp', 'webp'].includes(extension || '') || mimeType.startsWith('image/')) {
        return extractImageText(file);
    }

    throw new Error(`Tipo de archivo no soportado: .${extension}`);
}
